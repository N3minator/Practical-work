# Simple Graphical Application
import tkinter as tk
# For working with databases
import sqlite3

# Importing the auth.py file and its contents. And making functions _login | _register available inside this file
from auth import _login, _register
# Importing the BookLibrary.py file. And making the BookLibrary Class available inside this file
from BookLibrary import BookLibrary
# Importing the utils.py file. And making the functions focus_next_widget | on_mousewheel available inside this file
from utils import focus_next_widget, on_mousewheel

# This project has a total of 860 lines of code! This does not include file imports and libraries. There was not enough time to work on the design of the application, but the foundation of the application was worked out quite well.
# The project was created by Vitalii Derkach.


# File Start_Program.py | Serves as the starting point of the program and contains the database
class LoginRegisterApp:

    def __init__(self, root):
        # Initialization of the login/registration application with the passed root (main) window
        self.root = root
        self.root.title("Login / Register")

        # Creating labels and entry fields for login, password, and gmail
        login_label = tk.Label(root, text="Login:")
        login_label.grid(row=0, column=0, padx=10, pady=5)
        self.login_entry = tk.Entry(root)
        self.login_entry.grid(row=0, column=1, padx=10, pady=5)

        password_label = tk.Label(root, text="Password:")
        password_label.grid(row=1, column=0, padx=10, pady=5)
        self.password_entry = tk.Entry(root, show="*")
        self.password_entry.grid(row=1, column=1, padx=10, pady=5)

        gmail_label = tk.Label(root, text='Gmail:')
        gmail_label.grid(row=2, column=0, padx=10, pady=5)
        self.gmail_entry = tk.Entry(root)
        self.gmail_entry.grid(row=2, column=1, padx=10, pady=5)

        # Adding focus functions on Keyboard Keys in the input field and more
        self.login_entry.bind("<Return>", lambda event: focus_next_widget(self.password_entry))
        self.password_entry.bind("<Return>", lambda event: focus_next_widget(self.gmail_entry))
        self.gmail_entry.bind("<Return>", lambda event: self.__login())

        # Adding a checkbox to show the password
        self.show_password_var = tk.BooleanVar()
        show_password_checkbox = tk.Checkbutton(root, text="Show Password", variable=self.show_password_var,
                                                command=self.toggle_password_visibility)
        show_password_checkbox.grid(row=1, column=2, padx=5)

        # Creating buttons for login, registration, and gmail
        login_button = tk.Button(root, text="Login",
                                 command=self.__login)
        login_button.grid(row=3, column=0, columnspan=2, padx=10, pady=5, sticky="we")

        register_button = tk.Button(root, text="Register",
                                    command=self.__register)
        register_button.grid(row=4, column=0, columnspan=2, padx=10, pady=5, sticky="we")

        # Adding a button to reset input fields
        reset_button = tk.Button(root, text="Reset Input",
                                 command=self.reset_fields)
        reset_button.grid(row=5, column=0, columnspan=2, padx=10, pady=5, sticky="we")

        # Connecting to the database and creating a cursor
        self.conn = sqlite3.connect('BookLibrary.db')
        self.cursor = self.conn.cursor()
        self.create_tables()

    def create_tables(self):
        """Creates tables in the database."""
        with sqlite3.connect('BookLibrary.db') as conn:
            # Storing books
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS books
                              (login TEXT, id_books INTEGER PRIMARY KEY, name_books TEXT, author TEXT, genre TEXT, visible BOOLEAN)''')
            # Storing user data
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS users
                              (id_users INTEGER PRIMARY KEY, login TEXT, password_hash TEXT, gmail_user TEXT, admin_state TEXT)''')
            # Storing user data who borrowed books
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS user_books
                                  (id_users INTEGER,
                                   login TEXT,
                                   id_books INTEGER,
                                   date_rented TIMESTAMP, 
                                   return_date TIMESTAMP,
                                   FOREIGN KEY (id_users) REFERENCES users(id_users),
                                   FOREIGN KEY (id_books) REFERENCES books(id_books),
                                   FOREIGN KEY (login) REFERENCES users(login))''')
            conn.commit()

    # Login function in the auth.py file
    def __login(self):
        _login(self.conn, self.cursor, self.login_entry, self.password_entry, self.gmail_entry, self.open_library)

    # Registration function in the auth.py file
    def __register(self):
        _register(self.conn, self.cursor, self.login_entry, self.password_entry, self.gmail_entry, self.open_library)

    # Implementing the show password button functionality
    def toggle_password_visibility(self):
        # Function to toggle password visibility mode
        if self.show_password_var.get():
            self.password_entry.config(show="")
        else:
            self.password_entry.config(show="*")

    # Implementing the reset input button functionality
    def reset_fields(self):
        self.login_entry.delete(0, tk.END)
        self.password_entry.delete(0, tk.END)
        self.gmail_entry.delete(0, tk.END)

    # Function to open the Book Library window
    def open_library(self):
        # Saving the user login before closing the window
        self.user_login = self.login_entry.get().strip()

        # Closing the login/registration window
        self.root.destroy()
        # Initializing a new Book Library window
        win_booklibrary = tk.Tk()

        # Passing cursor and conn to the BookLibrary.py file
        BookLibrary(win_booklibrary, self.cursor, self.conn, self.user_login)

        # Renaming the program
        win_booklibrary.title("Book Library")

        # Setting default size
        win_booklibrary.geometry(f'350x200')
        # Disallowing window resizing
        win_booklibrary.resizable(width=False, height=False)
        # Main loop
        win_booklibrary.mainloop()


def open_login_register():
    # Function to open the login/registration window
    login_register_window = tk.Tk()
    # Disallowing window resizing for the login/registration window
    login_register_window.resizable(width=False, height=False)
    # Passing the registration window to the LoginRegisterApp class
    LoginRegisterApp(login_register_window)
    # Main loop
    login_register_window.mainloop()


# Standard procedure to run the program
if __name__ == "__main__":
    open_login_register()