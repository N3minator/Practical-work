# Simple Graphical Application
import tkinter as tk
# For displaying messages on the screen
from tkinter import messagebox

# Import the WinAppBooks.py file. And make the WinAppBooks Class available inside this file
from WinAppBooks import WinAppBooks


# File BookLibrary.py | performs the function of displaying the interface menu when the user has completed logging in/registering an account, it also performs non-complex functions from its list.
class BookLibrary(tk.Frame):

    def __init__(self, win_library, cursor, connect, login):

        # Transfer necessary data from the Start_Program.py file and assign them the self method for comfortable work in the BookLibrary class without using function arguments
        super().__init__(win_library)
        self.win_library = win_library
        self.cursor = cursor
        self.conn = connect
        self.login = login

        self.win_app_books = WinAppBooks(self.cursor, self.conn)

        # Creating user menu
        self.choice_label = tk.Label(win_library, text='''What do you want to do?

        1. View available books
        2. Rent a book
        3. Return a book
        4. View your list of rented books
        5. Search for a book''')
        self.choice_label.grid(row=0, column=0)
        self.choice_entry = tk.Entry(win_library)
        self.choice_entry.grid(row=1, column=0, columnspan=2, padx=10, pady=5)

        # Check if the user is an Administrator
        self.cursor.execute("SELECT admin_state FROM users WHERE login=?", (self.login,))
        admin_state = self.cursor.fetchone()

        # If the user is an Administrator, display additional menu
        if admin_state is not None and admin_state[0] == 'True':
            # Adding administrator options to the menu
            additional_options = '''
            6. View books rented by users (Admin)
            7. Add a book (Admin)
            8. Delete a book (Admin)'''
            self.choice_label.config(text=self.choice_label.cget('text') + additional_options)

        # Confirm user's choice by pressing Enter on the Keyboard
        self.win_library.bind('<Return>', lambda event: self.choice())

    # Function that processes user input and triggers the main program functionality in the WinAppBooks.py file
    def choice(self):
        # Store the user's choice from the choice input field
        choice = self.choice_entry.get().strip()

        if choice == '1':
            # Open the database with available books and retrieve information to books
            self.cursor.execute("SELECT * FROM books WHERE visible=1")
            books = self.cursor.fetchall()

            # If there are available books for temporary purchase, display information about them
            if books:
                books_info = '\n'.join(
                    [f"Book ID: {book[1]} | Title: {book[2]} | Author: {book[3]} | Genre: {book[4]}\n" for book in
                     books])
                messagebox.showinfo('Available Books', books_info)
            else:
                messagebox.showinfo('Available Books', 'There are currently no available books.')

        elif choice == '2':
            # Pass the main functions for working with the database cursor | conn to the WinAppBooks.py file in the __init__ function
            self.win_app_books.__init__(self.cursor, self.conn)
            # Trigger the menu functionality (2. Rent a book)
            self.win_app_books.buy_books(self.login)

        elif choice == '3':
            # Pass the main functions for working with the database cursor | conn to the WinAppBooks.py file in the __init__ function
            self.win_app_books.__init__(self.cursor, self.conn)
            # Trigger the menu functionality (3. Return a book)
            self.win_app_books.return_books(self.login)

        elif choice == '4':
            # Get the list of all books rented by the user
            self.cursor.execute("SELECT * FROM user_books WHERE login=?", (self.login,))
            rented_books = self.cursor.fetchall()

            if not rented_books:
                messagebox.showwarning('Your Books', 'Your library has no books.')
                return

            # For each rented book, get full information
            for book in rented_books:
                self.cursor.execute("SELECT * FROM books WHERE id_books=?", (book[2],))
                info = self.cursor.fetchone()

                if info:
                    books_info = '\n'.join([
                                               f"Book ID: {book[2]} | Taken: {book[3]} | Due: {book[4]}\n\nTitle: {info[2]} | Author: {info[3]} | Genre: {info[4]}\n"])
                    messagebox.showinfo('Your Books', books_info)
                else:
                    messagebox.showerror('Your Books', 'This book is missing from your library!')

        elif choice == '5':
            # Pass the main functions for working with the database cursor | conn to the WinAppBooks.py file in the __init__ function
            self.win_app_books.__init__(self.cursor, self.conn)
            # Trigger the menu functionality (5. Search for a book)
            self.win_app_books.search()

        elif choice == '6':
            # Open the database and find a user with this login and find out his Admin status
            self.cursor.execute("SELECT admin_state FROM users WHERE login=?", (self.login,))
            state_admin = self.cursor.fetchone()

            if state_admin[0] == 'True':
                self.list_rented_books()
            else:
                messagebox.showerror('Error!', 'You entered an incorrect number!')

        elif choice in ['7', '8']:
            self.cursor.execute("SELECT admin_state FROM users WHERE login=?", (self.login,))
            # if cursor.fetchone()[0] == 'True || Checks if the user is an Admin
            if self.cursor.fetchone()[0] == 'True':
                if choice == "7":
                    # Pass the main functions for working with the database cursor | conn to the WinAppBooks.py file in the __init__ function
                    self.win_app_books.__init__(self.cursor, self.conn)
                    # Trigger the menu functionality (7. Add a book (Admin))
                    self.win_app_books.add_book()
                else:
                    # Pass the main functions for working with the database cursor | conn to the WinAppBooks.py file in the __init__ function
                    self.win_app_books.__init__(self.cursor, self.conn)
                    # Trigger the menu functionality (8. Delete a book (Admin))
                    self.win_app_books.del_book()
            else:
                messagebox.showerror('Error!', 'You entered an incorrect number!')

        elif choice == '0':
            # Close the program menu (Close the program completely)
            self.win_library.destroy()
        else:
            messagebox.showerror('Error!', 'You entered an incorrect number!')

    def list_rented_books(self):
        """Displays a list of books rented by users."""
        self.cursor.execute("SELECT * FROM user_books")
        books = self.cursor.fetchall()

        # If someone has taken books. Execute code to display the list of Users who took Books
        if books:
            books_info = '\n'.join([f"Book ID: {book[2]} | Taken: {book[3]} | Due: {book[4]} | User: {book[1]} | User ID: {book[0]}\n" for book in books])
            messagebox.showinfo('Available books', books_info)
        else:
            messagebox.showwarning('No books on rent!', 'Currently, no one has taken any books :(')