# For hashing important data
import bcrypt
# Text handler
import re
# For generating random numbers
import random
# For displaying messages on the screen
from tkinter import messagebox

# In the functions, I added '_' to make it clear to other programmers that these functions should not be public. I cannot add '__' as they are not within a class.
# But this file is called in other functions that are inside classes and are private! All this is done for additional security of user data!

# File auth.py | is a very important file in terms of user data security! It performs account login/registration and hashing of important data!


def _login(conn, cursor, login_entry, password_entry, gmail_entry, open_library):

    login = login_entry.get().strip()
    password = password_entry.get().strip()
    gmail = gmail_entry.get().strip()

    validation_result, gmail = _validate_data(login, password, gmail)
    if not validation_result:
        return

    cursor.execute("SELECT password_hash, gmail_user FROM users WHERE login=?", (login,))
    user = cursor.fetchone()

    if user:
        if bcrypt.checkpw(password.encode(), user[0]) and gmail == user[1]:
            messagebox.showinfo("Success", "Login successful!")
            open_library()
        else:
            # Although there is also a check for Gmail here. But I don't want to make a separate text for Gmail + it is safer from intruders
            messagebox.showerror("Error", "Incorrect login or password!")
    else:
        messagebox.showerror("Error", "This user does not exist!")


def _register(conn, cursor, login_entry, password_entry, gmail_entry, open_library):

    login = login_entry.get().strip()
    password = password_entry.get().strip()
    gmail = gmail_entry.get().strip()

    validation_result, gmail = _validate_data(login, password, gmail)
    if not validation_result:
        return

    cursor.execute("SELECT COUNT(*) FROM users WHERE login = ? OR gmail_user = ?", (login, gmail))

    if cursor.fetchone()[0] == 0:
        hashed_password = bcrypt.hashpw(password.encode(), bcrypt.gensalt())

        while True:
            user_id_str = ''.join([str(random.randint(0, 9)) for _ in range(10)])
            user_id = int(user_id_str)
            cursor.execute("SELECT COUNT(*) FROM users WHERE id_users = ?", (user_id_str,))

            if cursor.fetchone()[0] == 0:
                del user_id_str
                break

        admin_state = 'False'

        cursor.execute(
            "INSERT INTO users (id_users, login, password_hash, gmail_user, admin_state) VALUES (?, ?, ?, ?, ?)",
            (user_id, login, hashed_password, gmail, admin_state))
        conn.commit()

        messagebox.showinfo("Registration", "Registration successful!")
        open_library()
    else:
        cursor.execute("SELECT COUNT(*) FROM users WHERE login = ?", (login,))
        login_count = cursor.fetchone()[0]

        if login_count > 0:
            messagebox.showerror('Error!', 'A user with this Login already exists!')
        else:
            messagebox.showerror('Error!', 'A user with this Gmail already exists!')


# Adding a function for data validation
def _validate_data(login, password, gmail):
    # To turn, for example, "  Vitalii    Derkach  " into "Vitalii Derkach"
    login = re.sub(r'\s+', ' ', login).strip()
    # This method removes only the leading and trailing spaces. But leaves spaces inside unchanged
    password = re.sub(r'^\s+|\s+$', '', password)
    # Remove all spaces in the Gmail string (Because Gmail cannot exist with spaces)
    gmail = gmail.replace(' ', '')

    # Add "@gmail.com" if it is not in the email address
    if not gmail.endswith('@gmail.com'):
        gmail += '@gmail.com'
    if not login and not password and not gmail:
        messagebox.showwarning("Warning", "Login/Password/Gmail cannot be empty!")
        return False
    elif len(password) < 8:
        messagebox.showwarning("Warning", "Password must be at least 8 characters long.")
        return False
    elif login.isdigit() or password.isdigit():
        messagebox.showwarning("Warning", "Login and password cannot consist only of digits.")
        return False
    else:
        # Return the updated value of gmail
        return True, gmail