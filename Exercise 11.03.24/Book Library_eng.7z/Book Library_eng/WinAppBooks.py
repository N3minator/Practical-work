# Simple Graphic Application
import tkinter as tk
# For displaying messages on the screen
from tkinter import messagebox
# Text handler
import re
from datetime import datetime, timedelta

# Importing utils.py file. And making the function focus_next_widget available inside this file
from utils import focus_next_widget, on_mousewheel


# File WinAppBooks.py | Is the main logic of the entire program! It performs the main operations, and it stores all additional windows!
class WinAppBooks:

    # Passing cursor | conn to init to be able to pass it inside the class without using arguments in functions!
    def __init__(self, cursor, connect):
        self.cursor = cursor
        self.conn = connect

    # Called from the menu (2. Buy)
    def buy_books(self, login):
        self.cursor.execute("SELECT * FROM books WHERE visible=1")
        books = self.cursor.fetchall()

        # If the library is empty, display a message and prevent the window from being launched
        if not books:
            messagebox.showwarning('..Empty..', 'Currently all books are sold out :(')
            return

        # Basic window creation
        win_buy_book = tk.Tk()
        win_buy_book.title("Buy Book")
        win_buy_book.geometry('750x200')
        win_buy_book.resizable(width=False, height=False)

        # Creating a scrollable area of the win_buy_book window (In case the information exceeds the window size)
        win_buy_book.grid_rowconfigure(0, weight=1)
        win_buy_book.grid_columnconfigure(0, weight=1)

        canvas = tk.Canvas(win_buy_book)
        canvas.grid(row=0, column=0, sticky="nsew")

        scrollbar = tk.Scrollbar(win_buy_book, command=canvas.yview, orient=tk.VERTICAL)
        scrollbar.grid(row=0, column=1, sticky="ns")

        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind_all("<MouseWheel>", lambda event: on_mousewheel(event, canvas))

        # Frame for placing elements
        frame = tk.Frame(canvas)
        canvas.create_window((0, 0), window=frame, anchor='nw')  # Change the initial position horizontally and vertically

        # Create text and input field
        choice_book_label = tk.Label(frame, text='Select the book ID:')
        choice_book_label.grid(row=0, column=0, padx=10, pady=5)
        self.choice_book_entry = tk.Entry(frame)
        self.choice_book_entry.grid(row=0, column=1, padx=10, pady=5)

        # Adding functionality to the Keyboard. So that you can confirm the input via Enter
        self.choice_book_entry.bind("<Return>", lambda event: self.confirmation_buy(win_buy_book, login))

        # For correct positioning of new information
        row = 1

        # Displaying all books that are currently not taken by users through a loop
        for book in books:
            book_info_label = tk.Label(frame, text=f"Book ID: {book[1]} | Title: {book[2]} | Author: {book[3]} | Genre: {book[4]}")
            book_info_label.grid(row=row, column=0, padx=10, pady=5, columnspan=2)
            row += 1

        # Waiting mode
        win_buy_book.mainloop()

    # Exception/error handler for Book Purchase
    def confirmation_buy(self, win_buy_book, login):
        # Pass the content from the 'Select the book ID' string
        book_id = self.choice_book_entry.get()

        # Check if there is such a book with such an ID in the database. And write the result to book_info
        self.cursor.execute("SELECT visible FROM books WHERE id_books=?", (book_id,))
        book_info = self.cursor.fetchone()

        # Write the user ID from the users table in the database to user_id
        self.cursor.execute("SELECT id_users FROM users WHERE login=?", (login,))
        user_id = self.cursor.fetchone()

        if book_info:
            # Write the status of the book into is_book_available. Whether it is taken or not
            is_book_available = book_info[0]

            # If the book is not taken, start the process of updating the book and user databases
            if is_book_available:
                # Close the 'Book Purchase' window
                win_buy_book.destroy()

                # Update the status of the book, that it has already been taken
                self.cursor.execute("UPDATE books SET visible=0 WHERE id_books=?", (book_id,))

                # Write down the time of taking the book
                date_rented = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
                # Write down the deadline by which the user needs to return the book. Set the return deadline in 7 days
                return_date = (datetime.now() + timedelta(days=7)).strftime("%d/%m/%Y")

                # Write into the database the user ID/Login of the user/ID of the book he took/Date of taking the book/Return deadline of the book
                self.cursor.execute("INSERT INTO user_books (id_users, login, id_books, date_rented, return_date) VALUES (?, ?, ?, ?, ?)",
                                    (user_id[0], login, book_id, date_rented, return_date))
                # In the Books database, write down the Login of the user, to make it easier to understand who took it. Detailed information should be viewed in the user_books table
                self.cursor.execute("UPDATE books SET login=? WHERE id_books=?", (login, book_id))
                # Save the changes in the database
                self.conn.commit()

                messagebox.showinfo('Success!', f"The book has been successfully rented until {return_date}.")
            else:
                messagebox.showwarning('Refusal!', 'This book is already taken!')
        else:
            messagebox.showerror('Error!', 'Incorrect book ID input!')

    # Called from the menu (3. Return book)
    def return_books(self, login):
        # Write all the information into the rented_books list of all books taken by users
        self.cursor.execute("SELECT * FROM user_books WHERE login=?", (login,))
        rented_books = self.cursor.fetchall()

        # If the user did not take any books, display a message and prevent the window from being launched
        if not rented_books:
            messagebox.showwarning('..Empty..', 'You haven\'t taken any books :0')
            return

        # Write the login passed from the Start_Program.py file and assign the self method for comfortable transfer inside the WinAppBooks class without using arguments in functions
        self.login = login

        # Initialize a new window Return Book
        win_return_book = tk.Tk()

        # Rename the program
        win_return_book.title("Return Book")

        # Set the default extension
        win_return_book.geometry(f'525x200')
        # Prevent resizing the window
        win_return_book.resizable(width=False, height=False)

        # Create a scrollable area of the win_return_book window (In case the information exceeds the window size)
        win_return_book.grid_rowconfigure(0, weight=1)
        win_return_book.grid_columnconfigure(0, weight=1)

        canvas = tk.Canvas(win_return_book)
        scrollbar = tk.Scrollbar(win_return_book, command=canvas.yview, orient=tk.VERTICAL)

        canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        scrollbar.grid(row=0, column=1, sticky="ns", rowspan=1)

        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind_all("<MouseWheel>", lambda event: on_mousewheel(event, canvas))

        # Frame for placing elements
        frame = tk.Frame(canvas)
        canvas.create_window((0, 0), window=frame,
                             anchor='nw')  # Change the initial position horizontally and vertically

        # Create text and input field
        return_book_label = tk.Label(frame, text="Enter the ID of the book you want to return:")
        return_book_label.grid(row=0, column=0, padx=10, pady=5)
        self.return_book_entry = tk.Entry(frame)
        self.return_book_entry.grid(row=0, column=1, padx=10, pady=5)
        self.return_book_entry.bind("<Return>", lambda event: self.confirmation_return(win_return_book))

        # For correct positioning of new information
        row = 1

        # Display all the books currently taken by users through a loop
        for book in rented_books:
            self.cursor.execute("SELECT * FROM books WHERE id_books=?", (book[2],))
            info = self.cursor.fetchone()

            # If information about the book is obtained, display it
            if info:
                book_info_label = tk.Label(frame,
                                           text=f"Book ID: {book[2]} | Taken: {book[3]} | Until: {book[4]}\nTitle: {info[2]} | Author: {info[3]} | Genre: {info[4]}")
                book_info_label.grid(row=row, column=0, padx=10, pady=5, columnspan=2)
                row += 1
            else:
                messagebox.showerror('Error', 'Information about rented books is unavailable.')

        # Waiting mode
        win_return_book.mainloop()

    # Exception/error handler for Returning Books
    def confirmation_return(self, win_return_book):
        # Pass the content from the 'Enter the ID of the book you want to return:' string
        id_book = self.return_book_entry.get()

        # Write the book ID from the user_books table
        self.cursor.execute("SELECT id_books FROM user_books WHERE login=?", (self.login,))
        check_id = self.cursor.fetchone()

        # If the ID from id_book entered by the user matches the database in which the ID of this book is stored. Then the code for returning the book is triggered
        if id_book == str(check_id[0]):
            # Close the 'Return Book' window
            win_return_book.destroy()
            # Update the status of this book, that it is now available again for temporary purchase
            self.cursor.execute("UPDATE books SET visible=1, login=NULL WHERE id_books=?", (id_book,))
            # Delete detailed information, where the data about when the user took it, etc. were stored
            self.cursor.execute("DELETE FROM user_books WHERE id_books=?", (id_book,))
            # Save the changes in the database
            self.conn.commit()

            messagebox.showinfo('Success!', 'You have successfully returned the book!')
        else:
            messagebox.showerror('Error', 'You entered the wrong ID!')

    # Called from the menu (7. Add a book (Admin))
    def add_book(self):
        # Initialize a new window for Adding a Book
        win_add_book = tk.Tk()

        # Rename the program
        win_add_book.title("Adding a Book")

        # Set the default extension
        win_add_book.geometry(f'325x200')
        # Prevent resizing the window
        win_add_book.resizable(width=False, height=False)

        # Create text and input fields
        name_book_label = tk.Label(win_add_book, text="Enter the book title:")
        name_book_label.grid(row=0, column=0, padx=10, pady=5)
        self.name_book_entry = tk.Entry(win_add_book)
        self.name_book_entry.grid(row=0, column=1, padx=10, pady=5)

        author_book_label = tk.Label(win_add_book, text="Enter the book author:")
        author_book_label.grid(row=1, column=0, padx=10, pady=5)
        self.author_book_entry = tk.Entry(win_add_book)
        self.author_book_entry.grid(row=1, column=1, padx=10, pady=5)

        genre_book_label = tk.Label(win_add_book, text="Enter the book genre:")
        genre_book_label.grid(row=2, column=0, padx=10, pady=5)
        self.genre_book_entry = tk.Entry(win_add_book)
        self.genre_book_entry.grid(row=2, column=1, padx=10, pady=5)

        visible_book_label = tk.Label(win_add_book, text='''Is the book available for rent?
        (1 - yes, 0 - no):''')
        visible_book_label.grid(row=3, column=0, padx=10, pady=5)
        visible_book_entry = tk.Entry(win_add_book)
        visible_book_entry.grid(row=3, column=1, padx=10, pady=5)

        # Add functionality for focusing on Keyboard Keys in the input field and more
        self.name_book_entry.bind("<Return>", lambda event: focus_next_widget(self.author_book_entry))
        self.author_book_entry.bind("<Return>", lambda event: focus_next_widget(self.genre_book_entry))
        self.genre_book_entry.bind("<Return>", lambda event: focus_next_widget(visible_book_entry))
        visible_book_entry.bind("<Return>", lambda event: self.confirmation_add(win_add_book, visible_book_entry))

        # Create a button for Confirmation
        confirmation_button = tk.Button(win_add_book, text="Confirmation",
                                        command=lambda: self.confirmation_add(win_add_book, visible_book_entry))
        confirmation_button.grid(row=4, column=0, columnspan=2, padx=10, pady=5, sticky="we")

        # Waiting mode
        win_add_book.mainloop()

    # Process of adding a Book to the database
    def confirmation_add(self, win_add_book, visible_book_entry):

        # Get the list of existing Book identifiers
        self.cursor.execute("SELECT id_books FROM books ORDER BY id_books ASC")
        existing_ids = [id_[0] for id_ in self.cursor.fetchall()]

        # Find the first available ID
        new_id = 1
        for id_ in existing_ids:
            if id_ != new_id:
                break
            new_id += 1

        # Write the entered information from the input field into variables
        name_book = self.name_book_entry.get()
        author_book = self.author_book_entry.get()
        genre_book = self.genre_book_entry.get()
        visible_book = visible_book_entry.get()

        # Check the validity of the data
        if not self.check_add_book(name_book, author_book, genre_book, visible_book):
            return

        self.cursor.execute("INSERT INTO books (id_books, name_books, author, genre, visible) VALUES (?, ?, ?, ?, ?)",
                            (new_id, name_book, author_book, genre_book, visible_book))
        # Save the changes in the database
        self.conn.commit()

        messagebox.showinfo('Success!', 'You have added a new book!')

        # Close the Adding a Book window
        win_add_book.destroy()

    # Exception/error handler for Adding a Book
    def check_add_book(self, name_book, author_book, genre_book, visible_book):

        # Cleaning and normalizing input
        name_book = re.sub(r'\s+', ' ', name_book).strip()
        author_book = re.sub(r'\s+', ' ', author_book).strip()
        genre_book = re.sub(r'\s+', ' ', genre_book).strip()
        visible_book = re.sub(r'\s+', ' ', visible_book).strip()

        # Attempt to convert visible_book to int
        try:
            visible_book = int(visible_book)
        except ValueError:
            messagebox.showerror('Error!', 'Invalid value for book availability! It should be 1 or 0.')
            return False
        # This check doesn't work well... I tried to implement it differently. But for some reason, it just doesn't work :/
        if not name_book or not author_book or not genre_book or not visible_book:
            messagebox.showerror('Error!', 'Fields cannot be empty!')
            return False
        if len(name_book) > 30:
            messagebox.showerror('Error!', 'The book title is too long!')
            return False
        if len(author_book) > 30:
            messagebox.showerror('Error!', 'The author\'s name is too long!')
            return False
        if len(genre_book) > 25:
            messagebox.showerror('Error!', 'The book genre is too long!')
            return False
        if visible_book not in [0, 1]:
            messagebox.showerror('Error!', 'Incorrect value for visibility field!')
            return False

        return True

    # Called from the menu (5. Search for a Book)
    def search(self):
        # Standard practice of creating an additional window
        win_library = tk.Tk()
        win_library.title("Search for a Book")
        win_library.geometry('350x100')
        win_library.resizable(width=False, height=False)

        # Create text and input fields
        search_name_label = tk.Label(win_library, text="Enter the search criteria for the title:")
        search_name_label.grid(row=1, column=0, sticky="w")
        self.search_name_entry = tk.Entry(win_library)
        self.search_name_entry.grid(row=1, column=1, sticky="we", padx=10)

        search_author_label = tk.Label(win_library, text="Enter the search criteria for the author:")
        search_author_label.grid(row=2, column=0, sticky="w")
        self.search_author_entry = tk.Entry(win_library)
        self.search_author_entry.grid(row=2, column=1, sticky="we", padx=10)

        search_genre_label = tk.Label(win_library, text="Enter the search criteria for the genre:")
        search_genre_label.grid(row=3, column=0, sticky="w")
        self.search_genre_entry = tk.Entry(win_library)
        self.search_genre_entry.grid(row=3, column=1, sticky="we", padx=10)

        # Add functionality for focusing on Keyboard Keys in the input field and more
        self.search_name_entry.bind("<Return>", lambda event: focus_next_widget(self.search_author_entry))
        self.search_author_entry.bind("<Return>", lambda event: focus_next_widget(self.search_genre_entry))
        self.search_genre_entry.bind("<Return>", lambda event: self.search_books())

        # Add the Search button that activates the Book Search function
        search_button = tk.Button(win_library, text="Search", command=self.search_books)
        search_button.grid(row=4, column=1, padx=10, pady=5)

        # Waiting mode
        win_library.mainloop()

    def search_books(self):
        # Record the data entered by the user from the input field
        search_name_query = self.search_name_entry.get()
        search_author_query = self.search_author_entry.get()
        search_genre_query = self.search_genre_entry.get()

        # Constructing the base query
        query = "SELECT id_books, name_books, author, genre, visible FROM books WHERE 1=1"

        # Adding search conditions if specified by the user in the field
        if search_name_query:
            query += " AND name_books LIKE '%" + search_name_query + "%'"
        if search_author_query:
            query += " AND author LIKE '%" + search_author_query + "%'"
        if search_genre_query:
            query += " AND genre LIKE '%" + search_genre_query + "%'"

        # Executing the query
        self.cursor.execute(query)
        search_results = self.cursor.fetchall()

        # Check if there are search results
        if search_results:
            # Display only the first result!!!
            book = search_results[0]
            messagebox.showinfo('Book Information',
                                f'Book ID: {book[0]} | Title: {book[1]} | Author: {book[2]} | Genre: {book[3]} | Availability: {book[4]}')
        else:
            # If no results found, display a message
            messagebox.showerror('Information', 'No book found with the specified criteria :(')

    # Called from the menu (8. Delete a book (Admin))
    def del_book(self):
        # Open the database with all the books in the Library and record the result in books
        self.cursor.execute("SELECT * FROM books")
        books = self.cursor.fetchall()

        # If the database with book information is empty, display a message and prevent creating an additional window
        if not books:
            messagebox.showwarning('..Empty..', 'The library is currently empty :(')
            return

        # Initialize a new window for Deleting Books
        win_del_book = tk.Tk()

        # Rename the program
        win_del_book.title("Delete Book")
        # Set the default extension
        win_del_book.geometry(f'900x350')
        # Prevent resizing the window
        win_del_book.resizable(width=False, height=False)

        # Create a scrollable area for the win_del_book window (In case the information exceeds the window size)
        win_del_book.grid_rowconfigure(0, weight=1)
        win_del_book.grid_columnconfigure(0, weight=1)

        canvas = tk.Canvas(win_del_book)
        canvas.grid(row=0, column=0, sticky="nsew")

        scrollbar = tk.Scrollbar(win_del_book, command=canvas.yview, orient=tk.VERTICAL)
        scrollbar.grid(row=0, column=1, sticky="ns")

        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind_all("<MouseWheel>", lambda event: on_mousewheel(event, canvas))

        # Frame for placing elements
        frame = tk.Frame(canvas)
        canvas.create_window((0, 0), window=frame, anchor='nw')

        # Create text and input fields
        choice_book_label = tk.Label(frame, text='Select the book ID to delete:')
        choice_book_label.grid(row=0, column=0, padx=10, pady=5)
        self.choice_delbook_entry = tk.Entry(frame)
        self.choice_delbook_entry.grid(row=0, column=1, padx=10, pady=5)

        # Add functionality on the Keyboard, so that when Enter is pressed, the function to confirm deletion of the book is executed
        self.choice_delbook_entry.bind("<Return>", lambda event: self.confirmation_del(win_del_book))

        # For correct positioning of new information
        row = 1

        # Display important information about all the books in the Library
        for book in books:
            book_info_label = tk.Label(frame,
                                       text=f"Taken By: {book[0]} | Book ID: {book[1]} | Title: {book[2]} | Author: {book[3]} | Genre: {book[4]} | Availability: {book[5]}")
            book_info_label.grid(row=row, column=0, padx=10, pady=5, columnspan=2)
            row += 1

        # Waiting mode
        win_del_book.mainloop()

    # Exception/error handler and also implements the Book Deletion process
    def confirmation_del(self, win_del_book):
        # Record the ID of the book to be deleted entered by the Administrator
        book_id = self.choice_delbook_entry.get()

        # Check if a book with such ID exists in the database, regardless of its status (whether it's borrowed or available).
        self.cursor.execute("SELECT * FROM books WHERE id_books=?", (book_id,))
        book_info = self.cursor.fetchone()

        # If a book with such ID exists in the database, the Book Deletion process is executed
        if book_info:
            # Close the Delete Book additional window
            win_del_book.destroy()

            # Open the database with the entered book for deletion, and save the data in book_info (or rather overwrite the variable)
            self.cursor.execute("SELECT * FROM books WHERE id_books=?", (book_id,))
            book_info = self.cursor.fetchone()

            # Display information about the Book deleted by the Administrator
            info_message = f'''\nBook ID: {book_info[0]} | Title: {book_info[1]} | Author: {book_info[2]} | Genre: {book_info[3]}'''

            messagebox.showinfo('Success!', 'The book has been successfully deleted! Book Information:\n' + info_message)

            # Delete this book from the Book Library
            self.cursor.execute("DELETE FROM books WHERE id_books=?", (book_id,))
            # Delete the data on who borrowed it, as the book no longer exists (Even if no one borrowed it, no errors will occur)
            self.cursor.execute("DELETE FROM user_books WHERE id_books=?", (book_id,))
            # Save the changes to the database
            self.conn.commit()
        else:
            messagebox.showerror('Error!', 'Incorrect book ID input!')

    # Exception/error handler and also implements the Book Deletion process
    def confirmation_del(self, win_del_book):
        # Record the ID of the book to be deleted entered by the Administrator
        book_id = self.choice_delbook_entry.get()

        # Check if a book with such ID exists in the database, regardless of its status (whether it's borrowed or available).
        self.cursor.execute("SELECT * FROM books WHERE id_books=?", (book_id,))
        book_info = self.cursor.fetchone()

        # If a book with such ID exists in the database, the Book Deletion process is executed
        if book_info:
            # Close the Delete Book additional window
            win_del_book.destroy()

            # Open the database with the entered book for deletion, and save the data in book_info (or rather overwrite the variable)
            self.cursor.execute("SELECT * FROM books WHERE id_books=?", (book_id,))
            book_info = self.cursor.fetchone()

            # Display information about the Book deleted by the Administrator
            info_message = f'''\nBook ID: {book_info[0]} | Title: {book_info[1]} | Author: {book_info[2]} | Genre: {book_info[3]}'''

            messagebox.showinfo('Success!', 'The book has been successfully deleted! Book Information:\n' + info_message)

            # Delete this book from the Book Library
            self.cursor.execute("DELETE FROM books WHERE id_books=?", (book_id,))
            # Delete the data on who borrowed it, as the book no longer exists (Even if no one borrowed it, no errors will occur)
            self.cursor.execute("DELETE FROM user_books WHERE id_books=?", (book_id,))
            # Save the changes to the database
            self.conn.commit()
        else:
            messagebox.showerror('Error!', 'Incorrect book ID input!')