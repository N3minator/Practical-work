# File utils.py | performs micro functions that are used in multiple files of the program. This is done in order to optimize the code size and avoid unnecessary code duplication

# Moves focus to the next widget in the input field.
def focus_next_widget(widget):
    widget.focus_set()


# Function for scrolling the mouse on the graphical window of the application
def on_mousewheel(event, canvas):
    canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")