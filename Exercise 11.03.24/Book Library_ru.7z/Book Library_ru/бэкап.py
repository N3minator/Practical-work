# Создаем прокручиваемую область окна win_return_book
win_return_book.grid_rowconfigure(0, weight=1)
win_return_book.grid_columnconfigure(0, weight=1)

canvas = tk.Canvas(win_return_book)
scrollbar = tk.Scrollbar(win_return_book, command=canvas.yview, orient=tk.VERTICAL)

canvas.grid(row=0, column=0, sticky="nsew")
scrollbar.grid(row=0, column=1, sticky="ns")
scrollbar.grid(row=0, column=1, sticky="ns", rowspan=1)

canvas.configure(yscrollcommand=scrollbar.set)
canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
canvas.bind_all("<MouseWheel>", lambda event: on_mousewheel(event, canvas))

frame = tk.Frame(canvas)
canvas.create_window((0, 0), window=frame, anchor='nw')  # Изменение начальной позиции по горизонтали и вертикали