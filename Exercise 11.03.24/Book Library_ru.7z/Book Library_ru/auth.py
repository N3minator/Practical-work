# Для хеширования важных данных
import bcrypt
# Обработчик текста
import re
# Для генерации случайных цифр
import random
# Для вывода сообщений на экран
from tkinter import messagebox

# В функциях я добавил '_' чтобы дать другим программистам понять. Что эти функции не должны быть в публичном виде. А добавить '__' я не могу, так как они не внутри класса.
# Но этот файл вызывается в других функциях которые находятся внутри классов и являются приватными! Сделано это все для дополнительной безопасности данных пользователей!

# Файл auth.py | является очень важным файлом в плане безопасности данных пользователей! Тут выполняется вход/регистрация аккаунта и хеширования важных данных!


def _login(conn, cursor, login_entry, password_entry, gmail_entry, open_library):

    login = login_entry.get().strip()
    password = password_entry.get().strip()
    gmail = gmail_entry.get().strip()

    validation_result, gmail = _validate_data(login, password, gmail)
    if not validation_result:
        return

    cursor.execute("SELECT password_hash, gmail_user FROM users WHERE login=?", (login,))
    user = cursor.fetchone()

    if user:
        if bcrypt.checkpw(password.encode(), user[0]) and gmail == user[1]:
            messagebox.showinfo("Успех", "Вход выполнен успешно!")
            open_library()
        else:
            # Хотя тут проверка на Gmail тоже есть. Но я не хочу делать отдельный текст для Gmail + это более безопасно от злоумышленников
            messagebox.showerror("Ошибка", "Неверный логин или пароль!")
    else:
        messagebox.showerror("Ошибка", "Данного пользователя не существует!")


def _register(conn, cursor, login_entry, password_entry, gmail_entry, open_library):

    login = login_entry.get().strip()
    password = password_entry.get().strip()
    gmail = gmail_entry.get().strip()

    validation_result, gmail = _validate_data(login, password, gmail)
    if not validation_result:
        return

    cursor.execute("SELECT COUNT(*) FROM users WHERE login = ? OR gmail_user = ?", (login, gmail))

    if cursor.fetchone()[0] == 0:
        hashed_password = bcrypt.hashpw(password.encode(), bcrypt.gensalt())

        while True:
            user_id_str = ''.join([str(random.randint(0, 9)) for _ in range(10)])
            user_id = int(user_id_str)
            cursor.execute("SELECT COUNT(*) FROM users WHERE id_users = ?", (user_id_str,))

            if cursor.fetchone()[0] == 0:
                del user_id_str
                break

        admin_state = 'False'

        cursor.execute(
            "INSERT INTO users (id_users, login, password_hash, gmail_user, admin_state) VALUES (?, ?, ?, ?, ?)",
            (user_id, login, hashed_password, gmail, admin_state))
        conn.commit()

        messagebox.showinfo("Регистрация", "Регистрация успешна!")
        open_library()
    else:
        cursor.execute("SELECT COUNT(*) FROM users WHERE login = ?", (login,))
        login_count = cursor.fetchone()[0]

        if login_count > 0:
            messagebox.showerror('Ошибка!', 'Пользователь с таким Логином уже существует!')
        else:
            messagebox.showerror('Ошибка!', 'Пользователь с таким Gmail уже существует!')


# Добавляем функцию для валидации данных
def _validate_data(login, password, gmail):
    # Чтобы получилось например из "  Vitalii    Derkach  " в "Vitalii Derkach"
    login = re.sub(r'\s+', ' ', login).strip()
    # Этот метод удаляет только вначале и конце пробелы. Но внутри пробелы он оставляет без изменений
    password = re.sub(r'^\s+|\s+$', '', password)
    # Удаляем все пробелы в строке Gmail (Так как Gmail с пробелами не может существовать)
    gmail = gmail.replace(' ', '')

    # Добавляем "@gmail.com", если его нет в адресе электронной почты
    if not gmail.endswith('@gmail.com'):
        gmail += '@gmail.com'
    if not login and not password and not gmail:
        messagebox.showwarning("Предупреждение", "Логин/Пароль/Gmail не могут быть пустыми!")
        return False
    elif len(password) < 8:
        messagebox.showwarning("Предупреждение", "Пароль должен содержать минимум 8 символов.")
        return False
    elif login.isdigit() or password.isdigit():
        messagebox.showwarning("Предупреждение", "Логин и пароль не могут состоять только из цифр.")
        return False
    else:
        # Возвращаем обновленное значение gmail
        return True, gmail
