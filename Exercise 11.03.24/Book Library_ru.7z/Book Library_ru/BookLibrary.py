# Простое Графическое Приложение
import tkinter as tk
# Для вывода сообщений на экран
from tkinter import messagebox

# Импортируем файл WinAppBooks.py. И делаем доступным вызов Класса WinAppBooks внутри этого файла
from WinAppBooks import WinAppBooks


# Файл BookLibrary.py | выполняет функцию вывода меню интерфейса, когда пользователь завершил вход/регистрацию аккаунта, так же он выполняет не сложные функции из своего списка.
class BookLibrary (tk.Frame):

    def __init__(self, win_library, cursor, connect, login):

        # Переносим необходимые данные из файла Start_Program.py и присваиваем им метод self для комфортной работы в классе BookLibrary без использования аргументов функций
        super().__init__(win_library)
        self.win_library = win_library
        self.cursor = cursor
        self.conn = connect
        self.login = login

        self.win_app_books = WinAppBooks(self.cursor, self.conn)

        # Создание меню пользователя
        self.choice_label = tk.Label(win_library, text='''Что вы хотите сделать?
        
        1. Посмотреть доступные книги
        2. Взять на прокат
        3. Вернуть книгу
        4. Посмотреть ваш список взятых книг
        5. Поиск Книги''')
        self.choice_label.grid(row=0, column=0)
        self.choice_entry = tk.Entry(win_library)
        self.choice_entry.grid(row=1, column=0, columnspan=2, padx=10, pady=5)

        # Узнаем являться ли пользователь Администратором
        self.cursor.execute("SELECT admin_state FROM users WHERE login=?", (self.login,))
        admin_state = self.cursor.fetchone()

        # Если пользователь является Администратором, то выводим дополнительное меню
        if admin_state is not None and admin_state[0] == 'True':
            # Добавление опций администратора к меню
            additional_options = '''
            6. Посмотреть взятые книги пользователями (Админ)
            7. Добавить книгу (Админ)
            8. Удалить книгу (Админ)'''
            self.choice_label.config(text=self.choice_label.cget('text') + additional_options)

        # Через Клавиатуру при нажатии Enter подтверждаем выбор действия пользователя
        self.win_library.bind('<Return>', lambda event: self.choice())

    # Функция, которая обрабатывает запрос пользователя, и запускает основной функционал программы в файле WinAppBooks.py
    def choice(self):
        # Записываем в choice выбор пользователя из поля ввода выбора действия
        choice = self.choice_entry.get().strip()

        if choice == '1':
            # Открываем базу данных с доступными книгами и записываем информацию в books
            self.cursor.execute("SELECT * FROM books WHERE visible=1")
            books = self.cursor.fetchall()

            # Если есть доступные книги для временной покупки, выводим информацию о них
            if books:
                books_info = '\n'.join([f"Номер книги: {book[1]} | Название книги: {book[2]} | Автор: {book[3]} | Жанр: {book[4]}\n" for book in books])
                messagebox.showinfo('Доступные книги', books_info)
            else:
                messagebox.showinfo('Доступные книги', 'В данный момент нет доступных книг.')

        elif choice == '2':
            # Передаем основные функции для работы с базой данных cursor | conn в файл WinAppBooks.py в функцию __init__
            self.win_app_books.__init__(self.cursor, self.conn)
            # Запускаем функционал меню (2. Взять на прокат)
            self.win_app_books.buy_books(self.login)

        elif choice == '3':
            # Передаем основные функции для работы с базой данных cursor | conn в файл WinAppBooks.py в функцию __init__
            self.win_app_books.__init__(self.cursor, self.conn)
            # Запускаем функционал меню (3. Вернуть книгу)
            self.win_app_books.return_books(self.login)

        elif choice == '4':
            # Получаем список всех книг, взятых пользователем
            self.cursor.execute("SELECT * FROM user_books WHERE login=?", (self.login,))
            rented_books = self.cursor.fetchall()

            if not rented_books:
                messagebox.showwarning('Ваши Книги', 'Вашей библиотеке отсутствуют книги.')
                return

            # Для каждой взятой книги получаем полную информацию
            for book in rented_books:
                self.cursor.execute("SELECT * FROM books WHERE id_books=?", (book[2],))
                info = self.cursor.fetchone()

                if info:
                    books_info = '\n'.join([f"ID Книги: {book[2]} | Взято: {book[3]} | До: {book[4]}\n\nНазвание книги: {info[2]} | Автор: {info[3]} | Жанр: {info[4]}\n"])
                    messagebox.showinfo('Ваши Книги', books_info)
                else:
                    messagebox.showerror('Ваши Книги', 'Вашей библиотеке отсутствует такая книга!')

        elif choice == '5':
            # Передаем основные функции для работы с базой данных cursor | conn в файл WinAppBooks.py в функцию __init__
            self.win_app_books.__init__(self.cursor, self.conn)
            # Запускаем функционал меню (5. Поиск Книги)
            self.win_app_books.search()

        elif choice == '6':
            # Открываем базу данных и ищем пользователя с таким логином и узнаем его статус Админа
            self.cursor.execute("SELECT admin_state FROM users WHERE login=?", (self.login,))
            state_admin = self.cursor.fetchone()

            if state_admin[0] == 'True':
                self.list_rented_books()
            else:
                messagebox.showerror('Ошибка!', 'Вы ввели не верное число!')

        elif choice in ['7', '8']:
            self.cursor.execute("SELECT admin_state FROM users WHERE login=?", (self.login,))
            # if cursor.fetchone()[0] == 'True || Проверяет является ли пользователей Админом
            if self.cursor.fetchone()[0] == 'True':
                if choice == "7":
                    # Передаем основные функции для работы с базой данных cursor | conn в файл WinAppBooks.py в функцию __init__
                    self.win_app_books.__init__(self.cursor, self.conn)
                    # Запускаем функционал меню (7. Добавить книгу (Админ))
                    self.win_app_books.add_book()
                else:
                    # Передаем основные функции для работы с базой данных cursor | conn в файл WinAppBooks.py в функцию __init__
                    self.win_app_books.__init__(self.cursor, self.conn)
                    # Запускаем функционал меню (8. Удалить книгу (Админ))
                    self.win_app_books.del_book()
            else:
                messagebox.showerror('Ошибка!', 'Вы ввели не верное число!')

        elif choice == '0':
            # Закрываем меню программы (Закрываем программу полностью)
            self.win_library.destroy()
        else:
            messagebox.showerror('Ошибка!', 'Вы ввели не верное число!')

    def list_rented_books(self):
        """Отображает список взятых книг пользователями."""
        self.cursor.execute("SELECT * FROM user_books")
        books = self.cursor.fetchall()

        # Если книги кто-то взял. Выполняем код отображения список Пользователей которые взяли Книги
        if books:
            books_info = '\n'.join([f"ID Книги: {book[2]} | Взято: {book[3]} | До: {book[4]} | Пользователь: {book[1]} | ID пользователя: {book[0]}\n" for book in books])
            messagebox.showinfo('Доступные книги', books_info)
        else:
            messagebox.showwarning('Нет книг на прокате!', 'В данный момент никто не взял книги :(')