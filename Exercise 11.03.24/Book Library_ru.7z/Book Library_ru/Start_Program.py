# Простое Графическое Приложение
import tkinter as tk
# Для работы с базами данных
import sqlite3

# Импортируем файл auth.py и его содержимое. И делаем доступным вызов функций _login | _register внутри этого файла
from auth import _login, _register
# Импортируем файл BookLibrary.py. И делаем доступным вызов Класса BookLibrary внутри этого файла
from BookLibrary import BookLibrary
# Импортируем файл utils.py. И делаем доступным вызов функции focus_next_widget | on_mousewheel внутри этого файла
from utils import focus_next_widget, on_mousewheel

# Данный проект имеет общий размер в 862 строк кода! Это без учета импортации файлов и библиотек. На проработку дизайна приложения не хватило времени, но основу приложения проработал достаточно нормально.
# Проект создавал Vitalii Derkach.

# Файл Start_Program.py | Является началом запуска программы, и хранит в себе базу данных
class LoginRegisterApp:

    def __init__(self, root):
        # Инициализация приложения входа/регистрации с переданным корневым (главным) окном
        self.root = root
        self.root.title("Вход / Регистрация")

        # Создание меток и полей для ввода логина и пароля и gmail
        login_label = tk.Label(root, text="Логин:")
        login_label.grid(row=0, column=0, padx=10, pady=5)
        self.login_entry = tk.Entry(root)
        self.login_entry.grid(row=0, column=1, padx=10, pady=5)

        password_label = tk.Label(root, text="Пароль:")
        password_label.grid(row=1, column=0, padx=10, pady=5)
        self.password_entry = tk.Entry(root, show="*")
        self.password_entry.grid(row=1, column=1, padx=10, pady=5)

        gmail_label = tk.Label(root, text='Gmail:')
        gmail_label.grid(row=2, column=0, padx=10, pady=5)
        self.gmail_entry = tk.Entry(root)
        self.gmail_entry.grid(row=2, column=1, padx=10, pady=5)

        # Добавляем функции фокуса на Клавиши клавиатуры в поле ввода и не только
        self.login_entry.bind("<Return>", lambda event: focus_next_widget(self.password_entry))
        self.password_entry.bind("<Return>", lambda event: focus_next_widget(self.gmail_entry))
        self.gmail_entry.bind("<Return>", lambda event: self.__login())

        # Добавление чек-бокса для отображения пароля
        self.show_password_var = tk.BooleanVar()
        show_password_checkbox = tk.Checkbutton(root, text="Показать пароль", variable=self.show_password_var,
                                                command=self.toggle_password_visibility)
        show_password_checkbox.grid(row=1, column=2, padx=5)

        # Создание кнопок для входа и регистрации и gmail
        login_button = tk.Button(root, text="Войти",
                                 command=self.__login)
        login_button.grid(row=3, column=0, columnspan=2, padx=10, pady=5, sticky="we")

        register_button = tk.Button(root, text="Зарегистрироваться",
                                    command=self.__register)
        register_button.grid(row=4, column=0, columnspan=2, padx=10, pady=5, sticky="we")

        # Добавляем кнопку сброса полей ввода
        reset_button = tk.Button(root, text="Сбросить ввод",
                                 command=self.reset_fields)
        reset_button.grid(row=5, column=0, columnspan=2, padx=10, pady=5, sticky="we")

        # Подключение к базе данных и создание курсора
        self.conn = sqlite3.connect('BookLibrary.db')
        self.cursor = self.conn.cursor()
        self.create_tables()

    def create_tables(self):
        """Создает таблицы в базе данных."""
        with sqlite3.connect('BookLibrary.db') as conn:
            # Хранение книг
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS books
                              (login TEXT, id_books INTEGER PRIMARY KEY, name_books TEXT, author TEXT, genre TEXT, visible BOOLEAN)''')
            # Хранение данных пользователей
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS users
                              (id_users INTEGER PRIMARY KEY, login TEXT, password_hash TEXT, gmail_user TEXT, admin_state TEXT)''')
            # Хранение данных пользователей которые взяли книги
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS user_books
                                  (id_users INTEGER,
                                   login TEXT,
                                   id_books INTEGER,
                                   date_rented TIMESTAMP, 
                                   return_date TIMESTAMP,
                                   FOREIGN KEY (id_users) REFERENCES users(id_users),
                                   FOREIGN KEY (id_books) REFERENCES books(id_books),
                                   FOREIGN KEY (login) REFERENCES users(login))''')
            conn.commit()

    # Функция входа в аккаунт в файле auth.py
    def __login(self):
        _login(self.conn, self.cursor, self.login_entry, self.password_entry, self.gmail_entry, self.open_library)

    # Функция регистрации аккаунта в файле auth.py
    def __register(self):
        _register(self.conn, self.cursor, self.login_entry, self.password_entry, self.gmail_entry, self.open_library)

    # Реализуем функционал кнопки показать пароль
    def toggle_password_visibility(self):
        # Функция для переключения режима отображения пароля
        if self.show_password_var.get():
            self.password_entry.config(show="")
        else:
            self.password_entry.config(show="*")

    # Реализуем функционал кнопки сбросить Ввод
    def reset_fields(self):
        self.login_entry.delete(0, tk.END)
        self.password_entry.delete(0, tk.END)
        self.gmail_entry.delete(0, tk.END)

    # Функция для открытия окна Библиотеки Книг
    def open_library(self):
        # Сохраняем логин пользователя перед закрытием окна
        self.user_login = self.login_entry.get().strip()

        # Закрываем окно входа/регистрации
        self.root.destroy()
        # Инициализируем новое окно Библиотеки Книг
        win_booklibrary = tk.Tk()

        # Передаем cursor и conn в файл BookLibrary.py
        BookLibrary(win_booklibrary, self.cursor, self.conn, self.user_login)

        # Переименовываем программу
        win_booklibrary.title("Библиотека Книг")

        # Устанавливаем расширение по умолчанию
        win_booklibrary.geometry(f'350x200')
        # Запрещаем менять размер окна
        win_booklibrary.resizable(width=False, height=False)
        # Режим ожидания
        win_booklibrary.mainloop()


def open_login_register():
    # Функция для открытия окна входа/регистрации
    login_register_window = tk.Tk()
    # Запрещаем менять размер окна входа/регистрации
    login_register_window.resizable(width=False, height=False)
    # Передача окна регистрации в класс LoginRegisterApp
    LoginRegisterApp(login_register_window)
    # Режим ожидания
    login_register_window.mainloop()


# Стандартная процедура запуска программы
if __name__ == "__main__":
    open_login_register()