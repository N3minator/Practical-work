# Простое Графическое Приложение
import tkinter as tk
# Для вывода сообщений на экран
from tkinter import messagebox
# Обработчик текста
import re
from datetime import datetime, timedelta

# Импортируем файл utils.py. И делаем доступным вызов функции focus_next_widget внутри этого файла
from utils import focus_next_widget, on_mousewheel


# Файл WinAppBooks.py | Является основной логикой всей программы! В нем выполняются основные операции, и в нем храниться все дополнительные окна!
class WinAppBooks:

    # Передаем в init cursor | conn чтобы его спокойно передавать внутри класса без использования аргументов в функциях!
    def __init__(self, cursor, connect):
        self.cursor = cursor
        self.conn = connect

    # Вызывается из меню (2. Взять на прокат)
    def buy_books(self, login):
        self.cursor.execute("SELECT * FROM books WHERE visible=1")
        books = self.cursor.fetchall()

        # Если библиотека пустая, выводим сообщение и предотвращаем запуска окна
        if not books:
            messagebox.showwarning('..Пусто..', 'В данный момент все книги распроданы :(')
            return

        # Базовое создание окна
        win_buy_book = tk.Tk()
        win_buy_book.title("Взять Книгу")
        win_buy_book.geometry('750x200')
        win_buy_book.resizable(width=False, height=False)

        # Создаем прокручиваемую область окна win_buy_book (На случай если информация превышает размеры окна)
        win_buy_book.grid_rowconfigure(0, weight=1)
        win_buy_book.grid_columnconfigure(0, weight=1)

        canvas = tk.Canvas(win_buy_book)
        canvas.grid(row=0, column=0, sticky="nsew")

        scrollbar = tk.Scrollbar(win_buy_book, command=canvas.yview, orient=tk.VERTICAL)
        scrollbar.grid(row=0, column=1, sticky="ns")

        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind_all("<MouseWheel>", lambda event: on_mousewheel(event, canvas))

        # Фрейм для размещения элементов
        frame = tk.Frame(canvas)
        canvas.create_window((0, 0), window=frame, anchor='nw')  # Изменение начальной позиции по горизонтали и вертикали

        # Создаем текст и поле ввода
        choice_book_label = tk.Label(frame, text='Выберите ID книги:')
        choice_book_label.grid(row=0, column=0, padx=10, pady=5)
        self.choice_book_entry = tk.Entry(frame)
        self.choice_book_entry.grid(row=0, column=1, padx=10, pady=5)

        # Добавляем функционал на Клавиатуру. Чтобы могли подтвердить ввод через Enter
        self.choice_book_entry.bind("<Return>", lambda event: self.confirmation_buy(win_buy_book, login))

        # Для правильного расположения новой информации
        row = 1

        # Выводим через цикл все книги которые в данный момент не взяты пользователями
        for book in books:
            book_info_label = tk.Label(frame, text=f"Номер ID книги: {book[1]} | Название книги: {book[2]} | Автор: {book[3]} | Жанр: {book[4]}")
            book_info_label.grid(row=row, column=0, padx=10, pady=5, columnspan=2)
            row += 1

        # Режим ожидания
        win_buy_book.mainloop()

    # Обработчик исключений/ошибок при Покупке Книги
    def confirmation_buy(self, win_buy_book, login):
        # Передаем содержимое из строки 'Выберите ID книги'
        book_id = self.choice_book_entry.get()

        # Проверяем в базе данных существует ли такая книга с таким ID. И записываем результат в book_info
        self.cursor.execute("SELECT visible FROM books WHERE id_books=?", (book_id,))
        book_info = self.cursor.fetchone()

        # Записываем в user_id ID пользователя из базы данных таблицы users
        self.cursor.execute("SELECT id_users FROM users WHERE login=?", (login,))
        user_id = self.cursor.fetchone()

        if book_info:
            # В is_book_available записываем статус книги. Взята она или нет
            is_book_available = book_info[0]

            # Если книга не взята, начинаем процесс обновления базы данных книги и пользователя
            if is_book_available:
                # Закрываем окно 'Взятия Книги'
                win_buy_book.destroy()

                # Обновляем статус книги, то что она уже взята
                self.cursor.execute("UPDATE books SET visible=0 WHERE id_books=?", (book_id,))

                # Записываем время взятия книги
                date_rented = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
                # Записываем срок до которого пользователю нужно вернуть книгу. Срок сдачи ставим через 7 дней
                return_date = (datetime.now() + timedelta(days=7)).strftime("%d/%m/%Y")

                # Записываем в базу данных ID пользователя/Логин пользователя/ID книги которую он взял/Дата взятия книги/Дата срока сдачи книги
                self.cursor.execute("INSERT INTO user_books (id_users, login, id_books, date_rented, return_date) VALUES (?, ?, ?, ?, ?)",
                                    (user_id[0], login, book_id, date_rented, return_date))
                # В базу данных Книг записываем Логин пользователя, чтобы было проще понять кем она взята. Детальную информацию нужно смотреть в таблице user_books
                self.cursor.execute("UPDATE books SET login=? WHERE id_books=?", (login, book_id))
                # Сохраняем изменения в базе данных
                self.conn.commit()

                messagebox.showinfo('Успех!', f"Книга успешно взята на прокат до {return_date}.")
            else:
                messagebox.showwarning('Отказ!', 'Данная книга уже взята!')
        else:
            messagebox.showerror('Ошибка!', 'Неверный ввод ID книги!')

    # Вызывается из меню (3. Вернуть книгу)
    def return_books(self, login):
        # Записываем всю информацию в rented_books список всех взятых книг пользователем
        self.cursor.execute("SELECT * FROM user_books WHERE login=?", (login,))
        rented_books = self.cursor.fetchall()

        # Если пользователь не брал книги, выводим сообщение и предотвращаем запуска окна
        if not rented_books:
            messagebox.showwarning('..Пусто..', 'Вы не брали никаких книг :0')
            return

        # Записываем логин переданный из файла Start_Program.py и присваиваем метод self для комфортной передачи внутри класса WinAppBooks без использования аргументов в функциях
        self.login = login

        # Инициализируем новое окно Возвращение Книги
        win_return_book = tk.Tk()

        # Переименовываем программу
        win_return_book.title("Возврат Книги")

        # Устанавливаем расширение по умолчанию
        win_return_book.geometry(f'525x200')
        # Запрещаем менять размер окна
        win_return_book.resizable(width=False, height=False)

        # Создаем прокручиваемую область окна win_return_book (На случай если информация превышает размеры окна)
        win_return_book.grid_rowconfigure(0, weight=1)
        win_return_book.grid_columnconfigure(0, weight=1)

        canvas = tk.Canvas(win_return_book)
        scrollbar = tk.Scrollbar(win_return_book, command=canvas.yview, orient=tk.VERTICAL)

        canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        scrollbar.grid(row=0, column=1, sticky="ns", rowspan=1)

        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind_all("<MouseWheel>", lambda event: on_mousewheel(event, canvas))

        # Фрейм для размещения элементов
        frame = tk.Frame(canvas)
        canvas.create_window((0, 0), window=frame, anchor='nw')  # Изменение начальной позиции по горизонтали и вертикали

        # Создаем текст и поле ввода
        return_book_label = tk.Label(frame, text="Введите ID книги которую хотите вернуть:")
        return_book_label.grid(row=0, column=0, padx=10, pady=5)
        self.return_book_entry = tk.Entry(frame)
        self.return_book_entry.grid(row=0, column=1, padx=10, pady=5)
        self.return_book_entry.bind("<Return>", lambda event: self.confirmation_return(win_return_book))

        # Для правильного расположения новой информации
        row = 1

        # Выводим через цикл все книги которые в данный момент взяты пользователями
        for book in rented_books:
            self.cursor.execute("SELECT * FROM books WHERE id_books=?", (book[2],))
            info = self.cursor.fetchone()

            # Если информация о книге получена, отображаем ее
            if info:
                book_info_label = tk.Label(frame, text=f"ID Книги: {book[2]} | Взято: {book[3]} | До: {book[4]}\nНазвание книги: {info[2]} | Автор: {info[3]} | Жанр: {info[4]}")
                book_info_label.grid(row=row, column=0, padx=10, pady=5, columnspan=2)
                row += 1
            else:
                messagebox.showerror('Ошибка', 'Информация о взятых книгах недоступна.')

        # Режим ожидания
        win_return_book.mainloop()

    # Обработчик исключений/ошибок при Возвращении Книги
    def confirmation_return(self, win_return_book):
        # Передаем содержимое из строки 'Введите ID книги которую хотите вернуть:'
        id_book = self.return_book_entry.get()

        # Записываем ID книги из таблицы user_books
        self.cursor.execute("SELECT id_books FROM user_books WHERE login=?", (self.login,))
        check_id = self.cursor.fetchone()

        # Если ID из id_book введенным пользователем совпадает с базой данной в которой храниться ID этой книги. То срабатывает код возвращение книги
        if id_book == str(check_id[0]):
            # Закрываем окно 'Возврат Книги'
            win_return_book.destroy()
            # Обновляем статус этой книги, что она теперь снова доступна для временной покупки
            self.cursor.execute("UPDATE books SET visible=1, login=NULL WHERE id_books=?", (id_book,))
            # Удаляем детальную информацию, где хранились данные когда пользователь её взял и тд
            self.cursor.execute("DELETE FROM user_books WHERE id_books=?", (id_book,))
            # Сохраняем изменения в базе данных
            self.conn.commit()

            messagebox.showinfo('Успех!', 'Вы успешно вернули книгу!')
        else:
            messagebox.showerror('Ошибка', 'Вы ввели не правильный ID!')

    # Вызывается из меню (7. Добавить книгу (Админ))
    def add_book(self):
        # Инициализируем новое окно Добавление Книги
        win_add_book = tk.Tk()

        # Переименовываем программу
        win_add_book.title("Добавление Книги")

        # Устанавливаем расширение по умолчанию
        win_add_book.geometry(f'325x200')
        # Запрещаем менять размер окна
        win_add_book.resizable(width=False, height=False)

        # Создаем текст и поле ввода
        name_book_label = tk.Label(win_add_book, text="Введите название книги:")
        name_book_label.grid(row=0, column=0, padx=10, pady=5)
        self.name_book_entry = tk.Entry(win_add_book)
        self.name_book_entry.grid(row=0, column=1, padx=10, pady=5)

        author_book_label = tk.Label(win_add_book, text="Введите автора книги:")
        author_book_label.grid(row=1, column=0, padx=10, pady=5)
        self.author_book_entry = tk.Entry(win_add_book)
        self.author_book_entry.grid(row=1, column=1, padx=10, pady=5)

        genre_book_label = tk.Label(win_add_book, text="Введите жанр книги:")
        genre_book_label.grid(row=2, column=0, padx=10, pady=5)
        self.genre_book_entry = tk.Entry(win_add_book)
        self.genre_book_entry.grid(row=2, column=1, padx=10, pady=5)

        visible_book_label = tk.Label(win_add_book, text='''Книга доступна для проката?
        (1 - да, 0 - нет):''')
        visible_book_label.grid(row=3, column=0, padx=10, pady=5)
        visible_book_entry = tk.Entry(win_add_book)
        visible_book_entry.grid(row=3, column=1, padx=10, pady=5)

        # Добавляем функции фокуса на Клавиши клавиатуры в поле ввода и не только
        self.name_book_entry.bind("<Return>", lambda event: focus_next_widget(self.author_book_entry))
        self.author_book_entry.bind("<Return>", lambda event: focus_next_widget(self.genre_book_entry))
        self.genre_book_entry.bind("<Return>", lambda event: focus_next_widget(visible_book_entry))
        visible_book_entry.bind("<Return>", lambda event: self.confirmation_add(win_add_book, visible_book_entry))

        # Создание кнопки для Подтверждения
        confirmation_button = tk.Button(win_add_book, text="Подтверждение", command=lambda: self.confirmation_add(win_add_book, visible_book_entry))
        confirmation_button.grid(row=4, column=0, columnspan=2, padx=10, pady=5, sticky="we")

        # Режим ожидания
        win_add_book.mainloop()

   # Процесс добавления Книги в базу данных
    def confirmation_add(self, win_add_book, visible_book_entry):

        # Получаем список существующих идентификаторов Книг
        self.cursor.execute("SELECT id_books FROM books ORDER BY id_books ASC")
        existing_ids = [id_[0] for id_ in self.cursor.fetchall()]

        # Находим первый свободный ID
        new_id = 1
        for id_ in existing_ids:
            if id_ != new_id:
                break
            new_id += 1

        # Записываем в переменные введенную информацию из поля ввода
        name_book = self.name_book_entry.get()
        author_book = self.author_book_entry.get()
        genre_book = self.genre_book_entry.get()
        visible_book = visible_book_entry.get()

        # Проверяем валидность данных
        if not self.check_add_book(name_book, author_book, genre_book, visible_book):
            return

        self.cursor.execute("INSERT INTO books (id_books, name_books, author, genre, visible) VALUES (?, ?, ?, ?, ?)",
                            (new_id, name_book, author_book, genre_book, visible_book))
        # Сохраняем изменения в базе данных
        self.conn.commit()

        messagebox.showinfo('Успех!', 'Вы добавили новую книгу!')

        # Закрываем окно Добавление Книг
        win_add_book.destroy()

    # Обработчик исключений/ошибок при Добавлении Книги
    def check_add_book(self, name_book, author_book, genre_book, visible_book):

        # Очистка и нормализация ввода
        name_book = re.sub(r'\s+', ' ', name_book).strip()
        author_book = re.sub(r'\s+', ' ', author_book).strip()
        genre_book = re.sub(r'\s+', ' ', genre_book).strip()
        visible_book = re.sub(r'\s+', ' ', visible_book).strip()

        # Попытка преобразовать visible_book в int
        try:
            visible_book = int(visible_book)
        except ValueError:
            messagebox.showerror('Ошибка!', 'Неправильное значение для доступности книги! Должно быть 1 или 0.')
            return False
        # Данная проверка плохо работает... Я пытался её по-разному реализовать. Но почему-то оно просто не хочет работать :/
        if not name_book or not author_book or not genre_book or not visible_book:
            messagebox.showerror('Ошибка!', 'Поля не могут быть пустыми!')
            return False
        if len(name_book) > 30:
            messagebox.showerror('Ошибка!', 'Слишком длинное название Книги!')
            return False
        if len(author_book) > 30:
            messagebox.showerror('Ошибка!', 'Слишком длинное имя Автора!')
            return False
        if len(genre_book) > 25:
            messagebox.showerror('Ошибка!', 'Слишком длинный жанр Книги!')
            return False
        if visible_book not in [0, 1]:
            messagebox.showerror('Ошибка!', 'Не правильное значение поля видимости!')
            return False

        return True

    # Вызывается из меню (5. Поиск Книги)
    def search(self):
        # Стандартная практика создания дополнительного окна
        win_library = tk.Tk()
        win_library.title("Поиск Книги")
        win_library.geometry('350x100')
        win_library.resizable(width=False, height=False)

        # Создаем текст и поле ввода
        search_name_label = tk.Label(win_library, text="Введите критерии названия поиска:")
        search_name_label.grid(row=1, column=0, sticky="w")
        self.search_name_entry = tk.Entry(win_library)
        self.search_name_entry.grid(row=1, column=1, sticky="we", padx=10)

        search_author_label = tk.Label(win_library, text="Введите критерии автора поиска:")
        search_author_label.grid(row=2, column=0, sticky="w")
        self.search_author_entry = tk.Entry(win_library)
        self.search_author_entry.grid(row=2, column=1, sticky="we", padx=10)

        search_genre_label = tk.Label(win_library, text="Введите критерии жанра поиска:")
        search_genre_label.grid(row=3, column=0, sticky="w")
        self.search_genre_entry = tk.Entry(win_library)
        self.search_genre_entry.grid(row=3, column=1, sticky="we", padx=10)

        # Добавляем функции фокуса на Клавиши клавиатуры в поле ввода и не только
        self.search_name_entry.bind("<Return>", lambda event: focus_next_widget(self.search_author_entry))
        self.search_author_entry.bind("<Return>", lambda event: focus_next_widget(self.search_genre_entry))
        self.search_genre_entry.bind("<Return>", lambda event: self.search_books())

        # Добавляем кнопку Поиск которая активирует функцию Поиска книг
        search_button = tk.Button(win_library, text="Поиск", command=self.search_books)
        search_button.grid(row=4, column=1, padx=10, pady=5)

        # Режим ожидания
        win_library.mainloop()

    def search_books(self):
        # Записываем данные введенные пользователем из поля ввода
        search_name_query = self.search_name_entry.get()
        search_author_query = self.search_author_entry.get()
        search_genre_query = self.search_genre_entry.get()

        # Формируем базовой запрос
        query = "SELECT id_books, name_books, author, genre, visible FROM books WHERE 1=1"

        # Добавляем условия поиска, если они указаны пользователем в поле
        if search_name_query:
            query += " AND name_books LIKE '%" + search_name_query + "%'"
        if search_author_query:
            query += " AND author LIKE '%" + search_author_query + "%'"
        if search_genre_query:
            query += " AND genre LIKE '%" + search_genre_query + "%'"

        # Выполняем запрос
        self.cursor.execute(query)
        search_results = self.cursor.fetchall()

        # Проверяем, есть ли результаты поиска
        if search_results:
            # Выводим только первый результат!!!
            book = search_results[0]
            messagebox.showinfo('Информация по книге', f'ID книги {book[0]} | Название книги {book[1]} | Автор {book[2]} | Жанр {book[3]} | Доступность {book[4]}')
        else:
            # Если результаты не найдены, выводим сообщение
            messagebox.showerror('Информация', 'Книга с указанными критериями не найдена :(')

    # Вызывается из меню (8. Удалить книгу (Админ))
    def del_book(self):
        # Открываем базу данных со всеми книгами в Библиотеке и записываем результат в books
        self.cursor.execute("SELECT * FROM books")
        books = self.cursor.fetchall()

        # Если база данных с информацией о книгах пустая. Выводим сообщение и предотвращаем создания дополнительного окна
        if not books:
            messagebox.showwarning('..Пусто..', 'В данный момент библиотека пустая :(')
            return

        # Инициализируем новое окно Удаление Книг
        win_del_book = tk.Tk()

        # Переименовываем программу
        win_del_book.title("Удалить Книгу")
        # Устанавливаем расширение по умолчанию
        win_del_book.geometry(f'900x350')
        # Запрещаем менять размер окна
        win_del_book.resizable(width=False, height=False)

        # Создаем прокручиваемую область окна win_del_book (На случай если информация превышает размеры окна)
        win_del_book.grid_rowconfigure(0, weight=1)
        win_del_book.grid_columnconfigure(0, weight=1)

        canvas = tk.Canvas(win_del_book)
        canvas.grid(row=0, column=0, sticky="nsew")

        scrollbar = tk.Scrollbar(win_del_book, command=canvas.yview, orient=tk.VERTICAL)
        scrollbar.grid(row=0, column=1, sticky="ns")

        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind_all("<MouseWheel>", lambda event: on_mousewheel(event, canvas))

        # Фрейм для размещения элементов
        frame = tk.Frame(canvas)
        canvas.create_window((0, 0), window=frame, anchor='nw')

        # Создаем текст и поле ввода
        choice_book_label = tk.Label(frame, text='Выберите ID книги для удаления:')
        choice_book_label.grid(row=0, column=0, padx=10, pady=5)
        self.choice_delbook_entry = tk.Entry(frame)
        self.choice_delbook_entry.grid(row=0, column=1, padx=10, pady=5)

        # Добавляем функционал на Клавиатуре, чтобы при нажатии Enter происходила функция подтверждения удаление книги
        self.choice_delbook_entry.bind("<Return>", lambda event: self.confirmation_del(win_del_book))

        # Для правильного расположения новой информации
        row = 1

        # Выводим важную информацию о всех книгах в Библиотеке
        for book in books:
            book_info_label = tk.Label(frame, text=f"Кем Взята: {book[0]} | Номер ID книги: {book[1]} | Название книги: {book[2]} | Автор: {book[3]} | Жанр: {book[4]} | Доступность: {book[5]}")
            book_info_label.grid(row=row, column=0, padx=10, pady=5, columnspan=2)
            row += 1

        # Режим ожидания
        win_del_book.mainloop()

    # Обработчик исключений/ошибок при Удалении Книги. Так же реализует процесс Удаления Книги
    def confirmation_del(self, win_del_book):
        # Записываем ID книги которую нужно удалить в book_id введенным Администратором
        book_id = self.choice_delbook_entry.get()

        # Проверяем, существует ли книга с таким ID, независимо от её статуса (взята она или доступна).
        self.cursor.execute("SELECT * FROM books WHERE id_books=?", (book_id,))
        book_info = self.cursor.fetchone()

        # Если книга с таким ID существует в базе данных, выполняется процесс Удаления Книги
        if book_info:
            # Закрываем дополнительное окно Удаление Книг
            win_del_book.destroy()

            # Открываем базу данных с ведённой книгой для удаления, и сохраняем данные в book_info (Точнее перезаписываем переменную)
            self.cursor.execute("SELECT * FROM books WHERE id_books=?", (book_id,))
            book_info = self.cursor.fetchone()

            # Выводим информацию какую Книгу Администратор удалил
            info_message = f'''\nНомер ID книги: {book_info[0]} | Название книги: {book_info[1]} | Автор: {book_info[2]} | Жанр: {book_info[3]}'''

            messagebox.showinfo('Успех!', 'Книга успешно удалена! Информация о Книге:\n' + info_message)

            # Удаляем эту книгу из Библиотеки Книг
            self.cursor.execute("DELETE FROM books WHERE id_books=?", (book_id,))
            # Удаляем данные кем она взята, так как книги больше не существует (Даже если её не кто не взял, ошибки не произойдет)
            self.cursor.execute("DELETE FROM user_books WHERE id_books=?", (book_id,))
            # Сохраняем изменения в базе данных
            self.conn.commit()
        else:
            messagebox.showerror('Ошибка!', 'Неверный ввод ID книги!')
