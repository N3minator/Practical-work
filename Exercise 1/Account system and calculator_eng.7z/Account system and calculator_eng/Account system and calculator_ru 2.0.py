import tkinter as tk
from tkinter import messagebox
import sqlite3
# pip install pysqlite3
from cryptography.fernet import Fernet
# pip install cryptography
import re
import bcrypt
# pip install bcrypt


# Initializing the login/registration application with the passed root (main) window
class LoginRegisterApp:

    def __init__(self, root):
        # Initializing the login/registration application with the passed root (main) window
        self.root = root
        self.root.title("Login / Registration")

        # Generating encryption key
        self.key = Fernet.generate_key()

        # Creating labels and entry fields for username and password input
        self.username_label = tk.Label(root, text="Username:")
        self.username_label.grid(row=0, column=0, padx=10, pady=5)
        self.username_entry = tk.Entry(root)
        self.username_entry.grid(row=0, column=1, padx=10, pady=5)

        self.password_label = tk.Label(root, text="Password:")
        self.password_label.grid(row=1, column=0, padx=10, pady=5)
        self.password_entry = tk.Entry(root, show="*")
        self.password_entry.grid(row=1, column=1, padx=10, pady=5)

        # Adding checkbox to show password
        self.show_password_var = tk.BooleanVar()
        self.show_password_checkbox = tk.Checkbutton(root, text="Show Password", variable=self.show_password_var,
                                                     command=self.toggle_password_visibility)
        self.show_password_checkbox.grid(row=1, column=2, padx=5)

        # Adding registration skip option
        self.skip_register = tk.BooleanVar()
        self.skip_register_checkbox = tk.Checkbutton(root, text='Skip Registration', variable=self.skip_register, command=self.skip_register_user)
        self.skip_register_checkbox.grid(row=0, column=2, padx=5)

        # Creating login and registration buttons
        self.login_button = tk.Button(root, text="Login", command=self.login)
        self.login_button.grid(row=2, column=0, columnspan=2, padx=10, pady=5, sticky="we")

        self.register_button = tk.Button(root, text="Register", command=self.register)
        self.register_button.grid(row=3, column=0, columnspan=2, padx=10, pady=5, sticky="we")

        # Adding reset button
        self.reset_button = tk.Button(root, text="Reset Input", command=self.reset_fields)
        self.reset_button.grid(row=4, column=0, columnspan=2, padx=10, pady=5, sticky="we")

        # conn and cursor are initialized in the class constructor __init__, and then used in the login and register functions without the need to pass them as arguments in (). This makes the code cleaner and more readable, and prevents code duplication.
        self.conn = sqlite3.connect('user_calculator.db')
        self.cursor = self.conn.cursor()

        # Creating user database if it doesn't exist
        self.create_database()

    def create_database(self):
        # Creating users table in SQLite database if it doesn't exist
        with sqlite3.connect('user_calculator.db') as conn:
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                                id INTEGER PRIMARY KEY,
                                username TEXT,
                                password_hash TEXT
                            )''')
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS user_sequence (
                                next_id INTEGER
                            )''')

            # Checking if there is already a record in the sequence table
            self.cursor.execute("SELECT * FROM user_sequence")
            if not self.cursor.fetchone():
                # If not, creating the first record with the initial value of 1
                self.cursor.execute("INSERT INTO user_sequence (next_id) VALUES (1)")
                conn.commit()

    def login(self):
        # Method to handle user login
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()

        # Checking data validity
        if not self.validate_data(username, password):
            return

        # Cleaning up spaces in username and password
        username = re.sub(r'\s+', ' ', username).strip()
        password = re.sub(r'^\s+|\s+$', '', password)

        if username.isdigit():
            messagebox.showerror("Error", "Username cannot consist only of digits!")
            return

        self.cursor.execute("SELECT password_hash FROM users WHERE username=?", (username,))
        user = self.cursor.fetchone()

        if user:
            if bcrypt.checkpw(password.encode(), user[0]):
                messagebox.showinfo("Success", "Login successful!")
                self.open_calculator()
            else:
                messagebox.showerror("Error", "Incorrect username or password!")
        else:
            messagebox.showerror("Error", "Incorrect username or password!")

    def register(self):
        # Method to handle registration of a new user
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()

        # Checking data validity
        if not self.validate_data(username, password):
            return

        # Cleaning up spaces in username and password
        username = re.sub(r'\s+', ' ', username).strip()
        password = re.sub(r'^\s+|\s+$', '', password)

        if username.isdigit():
            messagebox.showerror("Error", "Username cannot consist only of digits!")
            return
        elif password.isdigit():
            messagebox.showerror("Error", "Password cannot consist only of digits!")
            return
        elif len(password) < 8:
            messagebox.showerror("Error", "Password must be at least 8 characters long!")
            return

        # Checking if users with the given username exist
        self.cursor.execute("SELECT COUNT(*) FROM users WHERE username = ?", (username,))

        # If there is no user with this username, an account is created
        if self.cursor.fetchone()[0] == 0:
            # Hashing the password
            hashed_password = bcrypt.hashpw(password.encode(), bcrypt.gensalt())

            # Getting a list of existing user IDs
            self.cursor.execute("SELECT id FROM users ORDER BY id ASC")
            existing_ids = [id_[0] for id_ in self.cursor.fetchall()]

            # Finding the first available ID
            new_id = 1
            for id_ in existing_ids:
                if id_ != new_id:
                    break
                new_id += 1

            # Updating the next available ID in user_sequence if the new ID is greater than the current value
            self.cursor.execute("UPDATE user_sequence SET next_id = ? WHERE next_id < ?", (new_id + 1, new_id))

            # Adding a new user
            self.cursor.execute("INSERT INTO users (id, username, password_hash) VALUES (?, ?, ?)",
                                (new_id, username, hashed_password))
            self.conn.commit()

            messagebox.showinfo("Registration", "Registration successful!")
            self.root.after(100, self.open_calculator)
        else:
            messagebox.showerror('Error!', 'User with this username already exists!')

    # Adding function to validate data
    def validate_data(self, username, password):
        if not username or not password:
            messagebox.showwarning("Warning", "Username and password cannot be empty.")
            return False
        if len(password) < 8:
            messagebox.showwarning("Warning", "Password must be at least 8 characters long.")
            return False
        if username.isdigit() or password.isdigit():
            messagebox.showwarning("Warning", "Username and password cannot consist only of digits.")
            return False
        return True

    # Implementing functionality for Show Password button
    def toggle_password_visibility(self):
        # Function to toggle password visibility mode
        if self.show_password_var.get():
            self.password_entry.config(show="")
        else:
            self.password_entry.config(show="*")

    # Implementing functionality for Skip Registration button
    def skip_register_user(self):
        messagebox.showwarning('Caution!', 'You have logged in as Guest!')
        self.open_calculator()

    # Implementing functionality for Reset Input button
    def reset_fields(self):
        self.username_entry.delete(0, tk.END)
        self.password_entry.delete(0, tk.END)

    # Function to open the calculator window
    def open_calculator(self):
        # Closing the login/registration window
        self.root.destroy()
        # Function to open the calculator window
        calc_win = tk.Tk()

        # Passing the calculator window to the CalculatorApp class
        CalculatorApp(calc_win)

        # Renaming the program
        calc_win.title("Calculator")

        # Setting default size
        calc_win.geometry(f'238x265')
        # Disabling window resizing
        calc_win.resizable(width=False, height=False)
        # Setting background color
        calc_win['bg'] = 'black'

        # Main loop
        calc_win.mainloop()


class CalculatorApp(tk.Frame):
    def __init__(self, calc_win):
        super().__init__(calc_win)
        self.calc_win = calc_win

        # Input || justify=tk.LEFT - this property tells the text to align to the left
        # width=15 || specifies the number of characters that can be entered in the Entry field before it starts automatically wrapping text to a new line
        self.calc = tk.Entry(calc_win, justify=tk.LEFT, font=('Arial', 15), width=15)

        # Insert 0 into the string when the calculator starts
        self.calc.insert(0, '0')

        # Placement of the input field on the main window
        # Entry field || The columnspan attribute merges multiple columns
        self.calc.grid(row=0, column=0, columnspan=4, sticky='we')

        # padx=5, pady=5 controls the distance between buttons
        # bd=5 controls the thickness of borders || sticky='wens' || stretches the buttons
        self.make_digit_button('1').grid(row=1, column=0, sticky='wens', padx=5, pady=5)
        self.make_digit_button('2').grid(row=1, column=1, sticky='wens', padx=5, pady=5)
        self.make_digit_button('3').grid(row=1, column=2, sticky='wens', padx=5, pady=5)
        self.make_digit_button('4').grid(row=2, column=0, sticky='wens', padx=5, pady=5)
        self.make_digit_button('5').grid(row=2, column=1, sticky='wens', padx=5, pady=5)
        self.make_digit_button('6').grid(row=2, column=2, sticky='wens', padx=5, pady=5)
        self.make_digit_button('7').grid(row=3, column=0, sticky='wens', padx=5, pady=5)
        self.make_digit_button('8').grid(row=3, column=1, sticky='wens', padx=5, pady=5)
        self.make_digit_button('9').grid(row=3, column=2, sticky='wens', padx=5, pady=5)
        self.make_digit_button('0').grid(row=4, column=1, sticky='wens', padx=5, pady=5)

        self.make_operation_button('-').grid(row=4, column=0, sticky='wens', padx=5, pady=5)
        self.make_operation_button('+').grid(row=4, column=2, sticky='wens', padx=5, pady=5)

        self.make_clear_button('C').grid(row=1, column=3, sticky='wens', padx=5, pady=5)

        self.make_operation_button('/').grid(row=2, column=3, sticky='wens', padx=5, pady=5)
        self.make_operation_button('*').grid(row=3, column=3, sticky='wens', padx=5, pady=5)

        self.make_calc_button('=').grid(row=4, column=3, sticky='wens', padx=5, pady=5)

        # When Enter is pressed on the keyboard in the string, the calculator starts displaying the result without pressing the = button
        # `<Return>` indicates the Enter key on the keyboard
        self.calc_win.bind('<Return>', lambda event: self.calculate())

        # To remove the default 0 when entering digits from 0 to 9 on the keyboard
        self.calc.bind('1', self.add_keyboard_digit)
        self.calc.bind('2', self.add_keyboard_digit)
        self.calc.bind('3', self.add_keyboard_digit)
        self.calc.bind('4', self.add_keyboard_digit)
        self.calc.bind('5', self.add_keyboard_digit)
        self.calc.bind('6', self.add_keyboard_digit)
        self.calc.bind('7', self.add_keyboard_digit)
        self.calc.bind('8', self.add_keyboard_digit)
        self.calc.bind('9', self.add_keyboard_digit)
        self.calc.bind('0', self.add_keyboard_digit)

        # To remove the old operator when entering operators like on the graphical interface
        self.calc.bind('-', self.add_keyboard_operation)
        self.calc.bind('+', self.add_keyboard_operation)
        self.calc.bind('/', self.add_keyboard_operation)
        self.calc.bind('*', self.add_keyboard_operation)

        # To clear the input field when pressing the C key on the keyboard
        self.calc_win.bind('c', lambda event: self.clear())
        self.calc_win.bind('C', lambda event: self.clear())

        # This is done to set the minimum width of the columns so that they do not compress too much when the user resizes the window or when widgets are placed in them.
        # They also affect the size of the buttons on the right end
        self.calc_win.grid_columnconfigure(0, minsize=60)
        self.calc_win.grid_columnconfigure(1, minsize=60)
        self.calc_win.grid_columnconfigure(2, minsize=60)
        self.calc_win.grid_columnconfigure(3, minsize=60)

        # The grid row won't compress vertically to a size smaller than 60 pixels, even if it has no content or if the user resizes the window.
        self.calc_win.grid_rowconfigure(1, minsize=60)
        self.calc_win.grid_rowconfigure(2, minsize=60)
        self.calc_win.grid_rowconfigure(3, minsize=60)
        self.calc_win.grid_rowconfigure(4, minsize=60)

    def make_digit_button(self, digit):
        return tk.Button(self.calc_win, text=digit, bd=5, font=('Arial', 10), command=lambda: self.add_digit(digit))

    def add_digit(self, digit):
        value = self.calc.get()
        # When entering the first digits, the default digit 0 is deleted and a new digit entered from the interface is appended
        if value[-1] == '0' and len(value) == 1:
            value = value[1:]

        # Clear the input field and add the new digit
        self.calc.delete(0, tk.END)
        self.calc.insert(0, value + digit)

    def add_keyboard_digit(self, event):
        value = self.calc.get()
        # When entering the first digits, the default digit 0 is deleted and a new digit entered from the keyboard is appended
        if value and value[-1] == '0' and len(value) == 1:
            self.calc.delete(0, tk.END)

    def make_operation_button(self, operation):
        return tk.Button(self.calc_win, text=operation, bd=5, font=('Arial', 13), fg='#11d911', bg='#D3D3D3', command=lambda: self.add_operation(operation))

    def add_operation(self, operation):
        value = self.calc.get()
        # If the user presses the operator again, the previous operator will be replaced by the new one they selected
        if value[-1] in '+-/*':
            value = value[:-1]
        # Clear everything in the field
        self.calc.delete(0, tk.END)
        # Append the number we deleted and append the operator they recently selected from '+-/*'
        self.calc.insert(0, value + operation)

    def add_keyboard_operation(self, value):
        value = self.calc.get()
        # If the user enters the operator again, the previous operator will be replaced by the new one they entered from the keyboard
        if value[-1] in '+-/*':
            value = value[:-1]
        # Clear everything in the field
        self.calc.delete(0, tk.END)
        # Append the number we deleted and append the operator they recently selected from the keyboard '+-/*'
        self.calc.insert(0, value)

    def make_clear_button(self, operation):
        return tk.Button(self.calc_win, text=operation, bd=5, font=('Arial', 13), fg='#fb2c03', bg='#939393', command=self.clear)

    def clear(self):
        self.calc.delete(0, tk.END)
        self.calc.insert(0, '0')

    def make_calc_button(self, operation):
        return tk.Button(self.calc_win, text=operation, bd=5, font=('Arial', 13), fg='#ffffff', bg='#11d911', command=self.calculate)

    def calculate(self):
        # Take values ​​in input
        value = self.calc.get()
        # Remove all characters except "+-*/.," and digits
        value = re.sub(r"[^\d+\-*/.,]", "", value)
        # Remove all spaces from the string. The .strip() method is not suitable here because it only removes leading and trailing spaces in the string but does not remove spaces inside the string.
        value = value.replace(' ', '')

        # If the user enters, for example, 15+ and immediately activates =, then the calculator will calculate it like this 15+15=30
        if value[-1] in '+-/*':
            value = value + value[:-1]

        # This code splits the string by the '/' symbol, and then checks if the last element after splitting is equal to '0'. If yes, it displays an error message about division by zero.
        if '/' in value:
            parts = value.split('/')
            if len(parts) > 1 and parts[-1] == '0':
                messagebox.showerror("Error", "Division by zero!")
                return

        # Clear the input field
        self.calc.delete(0, tk.END)
        # Calculate and display the result || the eval function reads even a str string
        self.calc.insert(0, eval(value))


def open_login_register():
    # Function to open the login/register window
    login_register_window = tk.Tk()
    # Prevent resizing of the login/register window
    login_register_window.resizable(width=False, height=False)
    # Pass the registration window to the LoginRegisterApp class
    LoginRegisterApp(login_register_window)
    # Run in a loop
    login_register_window.mainloop()


if __name__ == "__main__":
    open_login_register()
