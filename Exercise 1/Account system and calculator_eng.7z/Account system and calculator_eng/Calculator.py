import tkinter as tk
from tkinter import messagebox
# pip install cryptography
import re


class CalculatorApp(tk.Frame):
    def __init__(self, calc_win):
        super().__init__(calc_win)
        self.calc_win = calc_win

        # Input || justify=tk.LEFT - this property tells the text to align to the left
        # width=15 || parameter specifies the number of characters that can be entered in the Entry field before it starts automatically wrapping text to a new line
        self.calc = tk.Entry(calc_win, justify=tk.LEFT, font=('Arial', 15), width=15)

        # Add '0' to the input field when the calculator starts
        self.calc.insert(0, '0')

        # Place the input field on the main window
        # Input field || The columnspan attribute merges multiple columns
        self.calc.grid(row=0, column=0, columnspan=4, stick='we')

        # padx=5, pady=5 controls the distance between the buttons
        # bd=5 controls the border thickness || stick='wens' || stretches the buttons
        self.make_digit_button('1').grid(row=1, column=0, stick='wens', padx=5, pady=5)
        self.make_digit_button('2').grid(row=1, column=1, stick='wens', padx=5, pady=5)
        self.make_digit_button('3').grid(row=1, column=2, stick='wens', padx=5, pady=5)
        self.make_digit_button('4').grid(row=2, column=0, stick='wens', padx=5, pady=5)
        self.make_digit_button('5').grid(row=2, column=1, stick='wens', padx=5, pady=5)
        self.make_digit_button('6').grid(row=2, column=2, stick='wens', padx=5, pady=5)
        self.make_digit_button('7').grid(row=3, column=0, stick='wens', padx=5, pady=5)
        self.make_digit_button('8').grid(row=3, column=1, stick='wens', padx=5, pady=5)
        self.make_digit_button('9').grid(row=3, column=2, stick='wens', padx=5, pady=5)
        self.make_digit_button('0').grid(row=4, column=1, stick='wens', padx=5, pady=5)

        self.make_operation_button('-').grid(row=4, column=0, stick='wens', padx=5, pady=5)
        self.make_operation_button('+').grid(row=4, column=2, stick='wens', padx=5, pady=5)

        self.make_clear_button('C').grid(row=1, column=3, stick='wens', padx=5, pady=5)

        self.make_operation_button('/').grid(row=2, column=3, stick='wens', padx=5, pady=5)
        self.make_operation_button('*').grid(row=3, column=3, stick='wens', padx=5, pady=5)

        self.make_calc_button('=').grid(row=4, column=3, stick='wens', padx=5, pady=5)

        # When Enter is pressed on the keyboard in the input field, the calculator starts displaying the result without pressing the = button
        # `<Return>` indicates the Enter key on the keyboard
        self.calc_win.bind('<Return>', lambda event: self.calculate())

        # To remove the default '0' when typing from 0 to 9 on the keyboard
        self.calc.bind('1', self.add_keyboard_digit)
        self.calc.bind('2', self.add_keyboard_digit)
        self.calc.bind('3', self.add_keyboard_digit)
        self.calc.bind('4', self.add_keyboard_digit)
        self.calc.bind('5', self.add_keyboard_digit)
        self.calc.bind('6', self.add_keyboard_digit)
        self.calc.bind('7', self.add_keyboard_digit)
        self.calc.bind('8', self.add_keyboard_digit)
        self.calc.bind('9', self.add_keyboard_digit)
        self.calc.bind('0', self.add_keyboard_digit)

        # To remove the old operator when typing from the keyboard
        self.calc.bind('-', self.add_keyboard_operation)
        self.calc.bind('+', self.add_keyboard_operation)
        self.calc.bind('/', self.add_keyboard_operation)
        self.calc.bind('*', self.add_keyboard_operation)

        # To clear the input field when pressing the C key on the keyboard
        self.calc_win.bind('c', lambda event: self.clear())
        self.calc_win.bind('C', lambda event: self.clear())

        # This is done to set the minimum width of the columns so that they do not compress too much when the user resizes the window or when widgets are placed in them.
        # They also affect the size of the buttons at the right end
        self.calc_win.grid_columnconfigure(0, minsize=60)
        self.calc_win.grid_columnconfigure(1, minsize=60)
        self.calc_win.grid_columnconfigure(2, minsize=60)
        self.calc_win.grid_columnconfigure(3, minsize=60)

        # The grid row will not compress vertically to a size smaller than 60 pixels, even if it has no content or if the user resizes the window.
        self.calc_win.grid_rowconfigure(1, minsize=60)
        self.calc_win.grid_rowconfigure(2, minsize=60)
        self.calc_win.grid_rowconfigure(3, minsize=60)
        self.calc_win.grid_rowconfigure(4, minsize=60)

    def make_digit_button(self, digit):
        return tk.Button(self.calc_win, text=digit, bd=5, font=('Arial', 10), command=lambda: self.add_digit(digit))

    def add_digit(self, digit):
        value = self.calc.get()
        # When entering the first digits, the default digit '0' is removed and a new digit entered from the interface is added
        if value[-1] == '0' and len(value) == 1:
            value = value[1:]

        # Clear the input field and add the new digit
        self.calc.delete(0, tk.END)
        self.calc.insert(0, value + digit)

    def add_keyboard_digit(self, event):
        value = self.calc.get()
        # When entering the first digits, the default digit '0' is removed and a new digit entered from the keyboard is added
        if value and value[-1] == '0' and len(value) == 1:
            self.calc.delete(0, tk.END)

    def make_operation_button(self, operation):
        return tk.Button(self.calc_win, text=operation, bd=5, font=('Arial', 13), fg='#11d911', bg='#D3D3D3', command=lambda: self.add_operation(operation))

    def add_operation(self, operation):
        value = self.calc.get()
        # If the user presses the operator again. Then the previous operator will be replaced with the new one they selected
        if value[-1] in '+-/*':
            value = value[:-1]
        # Clear everything
        self.calc.delete(0, tk.END)
        # Add the number we deleted and add the operator they recently selected from '+-/*'
        self.calc.insert(0, value + operation)

    def add_keyboard_operation(self, value):
        value = self.calc.get()
        # If the user enters the operator again. Then the previous operator will be replaced with the new one they typed on the keyboard
        if value[-1] in '+-/*':
            value = value[:-1]
        # Clear everything
        self.calc.delete(0, tk.END)
        # Add the number we deleted and add the operator they recently selected from the keyboard '+-/*'
        self.calc.insert(0, value)

    def make_clear_button(self, operation):
        return tk.Button(self.calc_win, text=operation, bd=5, font=('Arial', 13), fg='#fb2c03', bg='#939393', command=self.clear)

    def clear(self):
        self.calc.delete(0, tk.END)
        self.calc.insert(0, '0')

    def make_calc_button(self, operation):
        return tk.Button(self.calc_win, text=operation, bd=5, font=('Arial', 13), fg='#ffffff', bg='#11d911', command=self.calculate)

    def calculate(self):
        # Accept values in the input
        value = self.calc.get()
        # Remove all characters except "+-*/.," and digits
        value = re.sub(r"[^\d+\-*/.,]", "", value)
        # Remove all spaces from the string. The .strip() method is not suitable here because it only removes leading and trailing spaces in the string, but does not remove spaces inside the string.
        value = value.replace(' ', '')

        # If the user enters, for example, 15+ and immediately activates = then the calculator will calculate it as 15+15=30
        if value[-1] in '+-/*':
            value = value + value[:-1]

        # This code splits the string by the '/' character, then checks if the last element after splitting is '0'. If yes, it displays an error message about division by zero.
        if '/' in value:
            parts = value.split('/')
            if len(parts) > 1 and parts[-1] == '0':
                messagebox.showerror("Error", "Division by zero!")
                return

        # Clear the input field
        self.calc.delete(0, tk.END)
        # Calculate and display the result || the eval function reads even the str string
        self.calc.insert(0, eval(value))


def start_calculator():
    calc_win = tk.Tk()
    calc_win.title("Calculator")
    calc_win.geometry('238x265')
    calc_win.resizable(width=False, height=False)
    calc_win['bg'] = 'black'
    app = CalculatorApp(calc_win)  # Create an instance of the calculator application
    app.grid()  # If a packer is used to add widgets to the window
    calc_win.mainloop()


# If we need to open the Calculator without involving the Account system.py file
if __name__ == '__main__':
    start_calculator()
