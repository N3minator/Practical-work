import tkinter as tk
from tkinter import messagebox
import sqlite3
# pip install pysqlite3
from cryptography.fernet import Fernet
# pip install cryptography
import re
import bcrypt
# pip install bcrypt

# Launch the start_calculator function from the Calculator.py file
from Calculator import start_calculator


class LoginRegisterApp:

    def __init__(self, root):
        # Initialize the login/registration application with the passed root (main) window
        self.root = root
        self.root.title("Login / Registration")

        # Generate encryption key
        self.key = Fernet.generate_key()

        # Create labels and input fields for username and password
        self.username_label = tk.Label(root, text="Username:")
        self.username_label.grid(row=0, column=0, padx=10, pady=5)
        self.username_entry = tk.Entry(root)
        self.username_entry.grid(row=0, column=1, padx=10, pady=5)

        self.password_label = tk.Label(root, text="Password:")
        self.password_label.grid(row=1, column=0, padx=10, pady=5)
        self.password_entry = tk.Entry(root, show="*")
        self.password_entry.grid(row=1, column=1, padx=10, pady=5)

        # Add checkbox to show password
        self.show_password_var = tk.BooleanVar()
        self.show_password_checkbox = tk.Checkbutton(root, text="Show Password", variable=self.show_password_var,
                                                     command=self.toggle_password_visibility)
        self.show_password_checkbox.grid(row=1, column=2, padx=5)

        # Add registration skip checkbox
        self.skip_register = tk.BooleanVar()
        self.skip_register_checkbox = tk.Checkbutton(root, text='Skip Registration', variable=self.skip_register, command=self.skip_register_user)
        self.skip_register_checkbox.grid(row=0, column=2, padx=5)

        # Create buttons for login and registration
        self.login_button = tk.Button(root, text="Login", command=self.login)
        self.login_button.grid(row=2, column=0, columnspan=2, padx=10, pady=5, sticky="we")

        self.register_button = tk.Button(root, text="Register", command=self.register)
        self.register_button.grid(row=3, column=0, columnspan=2, padx=10, pady=5, sticky="we")

        # Add reset button
        self.reset_button = tk.Button(root, text="Reset Input", command=self.reset_fields)
        self.reset_button.grid(row=4, column=0, columnspan=2, padx=10, pady=5, sticky="we")

        # conn and cursor are initialized in the __init__ class constructor, and then used in the login and register functions without needing to pass them as arguments in (). This makes the code cleaner and more readable, and prevents code duplication.
        self.conn = sqlite3.connect('user_calculator.db')
        self.cursor = self.conn.cursor()

        # Create user database if it doesn't already exist
        self.create_database()

    def create_database(self):
        # Create users table in SQLite database if it doesn't already exist
        with sqlite3.connect('user_calculator.db') as conn:
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                                id INTEGER PRIMARY KEY,
                                username TEXT,
                                password_hash TEXT
                            )''')
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS user_sequence (
                                next_id INTEGER
                            )''')

            # Check if there is already a record in the sequence table
            self.cursor.execute("SELECT * FROM user_sequence")
            if not self.cursor.fetchone():
                # If not, create the first record with an initial value of 1
                self.cursor.execute("INSERT INTO user_sequence (next_id) VALUES (1)")
                conn.commit()

    def login(self):
        # Method to handle user login
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()

        # Check data validity
        if not self.validate_data(username, password):
            return

        # To convert, for example, "  Vitalii    Derkach  " to "Vitalii Derkach"
        username = re.sub(r'\s+', ' ', username).strip()
        # This method removes only leading and trailing spaces. But it leaves spaces inside the string unchanged
        password = re.sub(r'^\s+|\s+$', '', password)

        if username.isdigit():
            messagebox.showerror("Error", "Username cannot consist only of digits!")
            return

        self.cursor.execute("SELECT password_hash FROM users WHERE username=?", (username,))
        user = self.cursor.fetchone()

        if user:
            if bcrypt.checkpw(password.encode(), user[0]):
                messagebox.showinfo("Success", "Login successful!")
                self.open_calculator()
            else:
                messagebox.showerror("Error", "Incorrect username or password!")
        else:
            messagebox.showerror("Error", "Incorrect username or password!")

    def register(self):
        # Method to handle registration of a new user
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()

        # Check data validity
        if not self.validate_data(username, password):
            return

        # To convert, for example, "  Vitalii    Derkach  " to "Vitalii Derkach"
        username = re.sub(r'\s+', ' ', username).strip()
        # This method removes only leading and trailing spaces. But it leaves spaces inside the string unchanged
        password = re.sub(r'^\s+|\s+$', '', password)

        if username.isdigit():
            messagebox.showerror("Error", "Username cannot consist only of digits!")
            return
        elif password.isdigit():
            messagebox.showerror("Error", "Password cannot consist only of digits!")
            return
        elif len(password) < 8:
            messagebox.showerror("Error", "Password must be at least 8 characters long!")
            return

        # Check if users with this Username exist
        self.cursor.execute("SELECT COUNT(*) FROM users WHERE username = ?", (username,))

        # If a user with this Username does not exist. Then an account is created
        if self.cursor.fetchone()[0] == 0:
            # Hash the password
            hashed_password = bcrypt.hashpw(password.encode(), bcrypt.gensalt())

            # Get the list of existing user IDs
            self.cursor.execute("SELECT id FROM users ORDER BY id ASC")
            existing_ids = [id_[0] for id_ in self.cursor.fetchall()]

            # Find the first available ID
            new_id = 1
            for id_ in existing_ids:
                if id_ != new_id:
                    break
                new_id += 1

            # Update the next available ID in user_sequence if the new ID is greater than the current value
            self.cursor.execute("UPDATE user_sequence SET next_id = ? WHERE next_id < ?", (new_id + 1, new_id))

            # Add new user
            self.cursor.execute("INSERT INTO users (id, username, password_hash) VALUES (?, ?, ?)",
                                (new_id, username, hashed_password))
            self.conn.commit()

            messagebox.showinfo("Registration", "Registration successful!")
            self.root.after(100, self.open_calculator)
        else:
            messagebox.showerror('Error!', 'User with this Username already exists!')

    # Add function to validate data
    def validate_data(self, username, password):
        if not username or not password:
            messagebox.showwarning("Warning", "Username and password cannot be empty.")
            return False
        if len(password) < 8:
            messagebox.showwarning("Warning", "Password must be at least 8 characters long.")
            return False
        if username.isdigit() or password.isdigit():
            messagebox.showwarning("Warning", "Username and password cannot consist only of digits.")
            return False
        return True

    # Implement Show Password button functionality
    def toggle_password_visibility(self):
        # Function to toggle password visibility mode
        if self.show_password_var.get():
            self.password_entry.config(show="")
        else:
            self.password_entry.config(show="*")

    # Implement Skip Registration button functionality
    def skip_register_user(self):
        messagebox.showwarning('Caution!', 'You are logged in as Guest!')
        self.open_calculator()

    # Implement Reset Input button functionality
    def reset_fields(self):
        self.username_entry.delete(0, tk.END)
        self.password_entry.delete(0, tk.END)

    # Function to open the calculator window
    def open_calculator(self):
        self.root.destroy()  # Closes the current account management window
        start_calculator()  # Call the calculator function (start_calculator) from the Calculator.py file


def open_login_register():
    login_register_window = tk.Tk()
    login_register_window.resizable(width=False, height=False)
    LoginRegisterApp(login_register_window)
    login_register_window.mainloop()


if __name__ == "__main__":
    open_login_register()
